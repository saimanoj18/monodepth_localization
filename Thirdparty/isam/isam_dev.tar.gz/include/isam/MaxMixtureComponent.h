#pragma once

#include <Eigen/Dense>
#include "Noise.h"

namespace isam {
class MaxMixtureComponent {
public:
    double weight;
    Noise noise;

    MaxMixtureComponent (int dim) {
        weight = 1.;
        noise = Information (Eigen::MatrixXd::Identity (dim, dim));
    };

    /* might be a little faster if this returned log-probability */
    double evaluate (const Eigen::VectorXd &basicError) const {
        Eigen::MatrixXd L = noise.sqrtinf ().transpose () * noise.sqrtinf ();
        double normTerm = sqrt (((1./(2*M_PI))*L).determinant ());
        double c = weight*normTerm;
        double d = basicError.transpose () * L * basicError;
        double p = c * exp (-0.5 * d);
        return p;
    }
};
}
