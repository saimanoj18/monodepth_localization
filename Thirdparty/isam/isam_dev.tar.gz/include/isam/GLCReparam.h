/**
 * @file GLCReparam.h
 * @brief Generic Linear Constraint Reparametrization
 * @author Michael Kaess
 * @author Nicholas Carlevaris-Bianco
 * @version $Id: covariance.cpp 4975 2011-07-13 17:49:09Z kaess $
 *
 * [insert iSAM license]
 *
 */

#pragma once

#include <string>
#include <sstream>
#include <Eigen/Dense>

#include "Node.h"
#include "Factor.h"
#include "Anchor.h"

namespace isam {

/**
 * interface class to allow for reparametrization by the user
 * see GLC_RootShift implementation as an example
 */
class GLC_Reparam {

public:

  /**
   * set_nodes()
   * @param nodes Vector of Node pointers which support the factor
   */
  virtual void set_nodes (std::vector<Node*> nodes) = 0;
  /**
   * clone()
   * @return a new instance of the derived class
   */
  virtual GLC_Reparam* clone() = 0;
  /**
   * is_angle()
   * @return boolean vector indacating if elemetes reparameterized vector are angles
   */
  virtual Eigen::VectorXb is_angle() = 0;
  /**
   * jacobian()
   * @return jacobian of reparameterized output wrt node input
   */
  virtual Eigen::MatrixXd jacobian() = 0;
  /**
   * reparameterize()
   * @return reparameterized vector
   */
  virtual Eigen::VectorXd reparameterize (Selector s) = 0;

};

/**
 * GLC_RootShift
 * implementation of GLC_Reparam
 * performs root shift operation
 */
class GLC_RootShift : public GLC_Reparam {

private:
  std::vector<Node*> _nodes;
  Eigen::VectorXb _is_angle;
  int _dim; // input and output dim

public:

  void set_nodes (std::vector<Node*> nodes) {
    _nodes = nodes;
    _dim = 0;
    for (size_t i=0; i<_nodes.size(); i++) {
      _dim += _nodes[i]->dim();
    }
    _is_angle.resize(_dim);
    int ioff = 0;
    for (size_t i=0; i<_nodes.size(); i++) {
      _is_angle.segment(ioff, _nodes[i]->dim()) = _nodes[i]->is_angle();
      ioff += _nodes[i]->dim();
    }
  }
  
  GLC_RootShift* clone() {return new GLC_RootShift(*this);}
  Eigen::VectorXb is_angle() {return _is_angle;}
  Eigen::MatrixXd jacobian();
  Eigen::VectorXd reparameterize (Selector s);
  Eigen::VectorXd root_shift (Node* node_i, Node* node_j, Selector s);

};

} // namespace isam