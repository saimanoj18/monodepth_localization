/**
 * @file ChowLiuTree.h
 * @brief ChowLiuTree for information form Gaussian distributions
 * @author Michael Kaess
 * @author Nicholas Carlevaris-Bianco
 * @version $Id: covariance.cpp 4975 2011-07-13 17:49:09Z kaess $
 *
 * [insert iSAM license]
 *
 */

#pragma once

#include <string>
#include <vector>
#include <list>
#include <map>
#include <sstream>
#include <Eigen/Dense>

#include "Node.h"

#define GLC_EPS 1e-8

namespace Eigen {
  typedef Matrix<bool, Dynamic, Dynamic>MatrixXb;
}

namespace isam {


/**
 * ChowLiuTreeInfo
 * Information for Gaussian distribtuion for chow liu tree
 *
 */
class ChowLiuTreeInfo {

public:

  Eigen::MatrixXd L;
  std::vector<Node *> nodes;

  /**
   * Constructor.
   * @param L the information matrix
   * @param nodes the nodes in the information matrix
   */
  ChowLiuTreeInfo (Eigen::MatrixXd L_, std::vector<Node *> nodes_)
      : L(L_), nodes(nodes_) { }

  //const std::vector<Node *>& nodes() {return _nodes;}
  int num_nodes() {return nodes.size();}

  /**
   * Marginal distribution
   * @return Information matrix P(node[id])
   */
  Eigen::MatrixXd marginal(int id);

  /**
   * Joint distribution
   * @return Information matrix P(node[ida], node[idb])
   */
  Eigen::MatrixXd joint(int ida, int idb); // a, b

  /**
   * Conditional distribution
   * @return Information matrix P(node[ida] | node[idb])
   */
  Eigen::MatrixXd conditional(int ida, int idb);

};

/**
 * ChowLiuTreeNode
 * A node in the chowliu tree
 *
 */
class ChowLiuTreeNode {

public:
  
  int id;
  int pid;
  std::vector<int> cids;
  Eigen::MatrixXd marginal;     // marginal information
  Eigen::MatrixXd conditional;  // conditional information with parrent
  Eigen::MatrixXd joint;        // joint information with parrent
  
  bool is_root () { return (pid == -1) ? true : false; }
  bool is_leaf () { return (cids.size() == 0) ? true : false; }

};

class MI {
  
public:
  int id1;
  int id2;
  double mi;

  MI (int id1_, int id2_, double mi_)
    : id1(id1_), id2(id2_), mi(mi_){
  }

};

/**
 * ChowLiuTreeFactor
 * a factor produced by the tree
 *
 */
class ChowLiuTreeFactor {

public:
  Eigen::MatrixXd L;          // factor information
  std::vector<Node*> nodes;   // factor support
};


/**
 * ChowLiuTree
 * Chow Liu Tree class for information form gaussian distribtuions
 *
 */
class ChowLiuTree {

  ChowLiuTreeInfo _clt_info;
  std::list<MI> _edges;

  void _calc_edges(void);
  double _calc_mi(int ida, int idb);
  void _max_span_tree(void);
  void _build_tree_rec(int id, int pid);
  void _calc_factors(void);
  Eigen::MatrixXd _expand_factor_information(const ChowLiuTreeFactor &cltf);
  void _unexpand_factor_information (const Eigen::MatrixXd &L_full, ChowLiuTreeFactor &cltf);
  Eigen::MatrixXb _sparsity_pattern(void);
  bool _is_conservative(void);
  void _ensure_conservative_ci(void);   // covariance intersection
  void _ensure_conservative_wf(void);   // weighted factors
  void _ensure_conservative_wev(void);  // weighted eigen values
  void _ensure_conservative_jv(void);   // john vial's method
  void _update_info(Eigen::MatrixXd L); // rebuilds tree and recalc factors with new target information

public:

  // the resulting chow-liu tree
  std::map<int, ChowLiuTreeNode> tree;
  // the resulting factors
  std::vector<ChowLiuTreeFactor> factors;

  ChowLiuTree (Eigen::MatrixXd L, std::vector<Node *> nodes);
  
};


} // namespace isam