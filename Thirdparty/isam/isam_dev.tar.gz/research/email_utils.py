import smtplib

def send_text_message(message):
    fromaddress = "dmrosen@mit.edu"
    toaddress = "13109861056@tmomail.net"

    server = smtplib.SMTP('outgoing.mit.edu')
    server.sendmail(fromaddress, toaddress, message)
    server.quit()

def send_notification_email(message):
    fromaddress = "dmrosen@mit.edu"
    toaddress = "dmrosen@mit.edu"
    
    server = smtplib.SMTP('outgoing.mit.edu')
    server.sendmail(fromaddress, toaddress, message)
    server.quit()

