/**
 * @file metric_nchi2.cpp
 * @brief Example of a metric (normalized chi-square) for SLAM evaluation.
 * @author Michael Kaess
 * @version $Id: metric_nchi2.cpp 6335 2012-03-22 23:13:52Z kaess $
 *
 */

// Todo: Should move some stuff to libraries to be used for other metrics without code duplication.

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>

#include <cmath>
#include <iostream>
#include <sstream>
#include <fstream>

#include <list>
#include <map>

using namespace std;

#ifndef PI
const double PI = 3.14159265358979323846;
#endif
const double TWOPI = 2.0 * PI;

/**
 * Normalize angle to be within the interval [-pi,pi].
 */
inline double standardRad(double t) {
  if (t >= 0.) {
    t = fmod(t + PI, TWOPI) - PI;
  } else {
    t = fmod(t - PI, -TWOPI) + PI;
  }
  return t;
}

class Pose2d {
public:
  static const int dim = 3;
  double x, y, t;
  Pose2d() :
    x(0.), y(0.), t(0.) {
  }
  Pose2d(double x, double y, double t) :
    x(x), y(y), t(t) {
  }
  Pose2d ominus(const Pose2d& b) const {
    double c = cos(b.t);
    double s = sin(b.t);
    double dx = x - b.x;
    double dy = y - b.y;
    double ox = c * dx + s * dy;
    double oy = -s * dx + c * dy;
    double ot = t - b.t;
    return Pose2d(ox, oy, ot);
  }
};

class Constraint2d {
public:
  static const int dim = 3;
  unsigned int idx_x0, idx_x1;
  double x, y, t;
  double sxx, sxy, sxt, syy, syt, stt;
  double weighted_sse(map<int, Pose2d>& estimates) {
    if (estimates.find(idx_x0) == estimates.end()
        || estimates.find(idx_x1) == estimates.end()) {
      cerr << "Estimate does not exist: " << idx_x0 << " or " << idx_x1 << endl;
    }
    Pose2d& p1 = estimates[idx_x0];
    Pose2d& p2 = estimates[idx_x1];
    Pose2d pred = p2.ominus(p1);
    double e_x = pred.x - x;
    double e_y = pred.y - y;
    double e_t = standardRad(pred.t - t);
    double w_x = sxx * e_x + sxy * e_y + sxt * e_t;
    double w_y = syy * e_y + syt * e_t;
    double w_t = stt * e_t;
    double wsse = w_x * w_x + w_y * w_y + w_t * w_t;
    return wsse;
  }
};

class Metric {

  list<Constraint2d> constraints;
  map<int, Pose2d> estimates;
  ifstream infile;

public:

  void open(const char* fname) {
    infile.open(fname, ifstream::in);
  }

  /**
   * Get the next line from the data file.
   * @param line Contains new line upon return.
   * @return Returns false if no valid data can be read (eg. EOF).
   */
  bool read_line(string& line) {
    if (!infile.good()) {
      return false;
    }
    getline(infile, line);
    if (line.length() == 0) {
      return false;
    }
    return true;
  }

  /**
   * Parse a constraint line and add to list of constraints.
   * @param line Line to parse.
   */
  void add_constraint(const string& line) {
    istringstream iss(line);
    string command;
    iss >> command;
    if (command == "Constraint2") {
      Constraint2d o;
      iss >> o.idx_x0 >> o.idx_x1 >> o.x >> o.y >> o.t
          >> o.sxx >> o.sxy >> o.sxt >> o.syy >> o.syt >> o.stt;
      constraints.push_back(o);
    } else {
      cerr << "Constraint type " << command << " not recognized" << endl;
      exit(1);
    }
  }

  /**
   * Remove all current estimates before loading next set of estimates.
   */
  void reset_estimates() {
    estimates.clear();
  }

  /**
   * Parse an estimate line and add to estimates.
   * @param line Line to parse.
   */
  void add_estimate(const string& line) {
    istringstream iss(line);
    string command;
    iss >> command;
    if (command == "Pose2") {
      unsigned int idx;
      Pose2d p;
      iss >> idx >> p.x >> p.y >> p.t;
      estimates[idx] = p;
    } else {
      cerr << "Estimate type " << command << " not recognized" << endl;
      exit(1);
    }
  }

  /**
   * Read in constraints until a SOLVE command.
   * @return False if end of file reached.
   */
  bool read_constraints() {
    string line;
    bool more = true;
    while ((more = read_line(line))) {
      if (line == "SOLVE") {
        break;
      }
      add_constraint(line);
    }
    return more;
  }

  /**
   * Read in estimates until next END command.
   * @return False if end of file reached.
   */
  bool read_estimates() {
    string line;
    bool data_available = false;
    reset_estimates();
    while (read_line(line)) {
      if (line.substr(0, 3) == "END") {
        break;
      }
      add_estimate(line);
      data_available = true;
    }
    return data_available;
  }

  /**
   * Evaluate the actual metric, here normalized chi-square.
   * @return Normalized chi-square.
   */
  double evaluate() {
    // weighted sum of squared errors
    double weighted_sse = 0.;
    int dim_measure = 0;
    for (list<Constraint2d>::iterator it = constraints.begin(); it != constraints.end(); it++) {
      weighted_sse += it->weighted_sse(estimates);
      dim_measure += Constraint2d::dim;
    }
    int dim_estimates = 0;
    // Todo: How to deal with unary constraints on the first pose? This really
    // depends on the implementation, as the first pose can equally well be
    // made a constant, in which case there are less degrees of freedom. So I
    // chose here to ignore any unary constraint on the first pose, and instead
    // remove the first pose from the number of degrees of freedom.
    bool first = true;
    for (map<int, Pose2d>::iterator it = estimates.begin(); it != estimates.end(); it++) {
      if (first) {
        first = false;
      } else {
        dim_estimates += Pose2d::dim;
      }
    }
    int dof = dim_measure - dim_estimates;
    double norm_chi2 = 0.;
    if (dof > 0) {
      norm_chi2 = weighted_sse / (double) dof;
    } else {
      norm_chi2 = 1. / 0.;
    }
    cout << norm_chi2 << endl;
    return norm_chi2;
  }

  void close() {
    infile.close();
  }

};

/**
 * Where everything starts.
 */
int main(int argc, char* argv[]) {

  char* fname;
  if (argc == 1) {
    fname = (char*) "/dev/stdin";
  } else if (argc == 2) {
    fname = argv[1];
  } else {
    cerr << "Usage: metric_nchi2 [data_file]" << endl;
    exit(1);
  }

  Metric metric;
  metric.open(fname);

  bool more = true;
  while (more) {
    more = metric.read_constraints();
    if (more) {
      more = metric.read_estimates();
      if (more) {
        metric.evaluate();
      }
    }
  }

  metric.close();

  return 0;
}
