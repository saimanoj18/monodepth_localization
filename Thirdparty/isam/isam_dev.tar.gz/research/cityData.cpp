/**
 * @file cityData.cpp
 * @brief Create 2D city block simulation data.
 * @author Hordur Johannsson
 * @author Michael Kaess
 * @version $Id: cityData.cpp 6572 2012-04-29 23:14:50Z kaess $
 */

#include <ctime>
#include <cstdio>
#include <isam/Pose3d.h>
#include <map>
#include <vector>

using namespace std;
using namespace isam;
using namespace Eigen;

const bool USE_LANDMARKS = true;
const bool USE_LOOP_CLOSURE = true;
const bool ADD_NOISE = true;
const bool FLAT_3D = false; // save flat Manhattan world as 3D/6DOF data
const bool TORUS = true; // wrap Manhattan world around torus
const int DIRECTION_SAMPLING = 2; // 1 - pick direction at random
                                  // 2 - pick forward, left, right, backward with different probabilities
const int HEIGHT = 20;
const int WIDTH = 20;
const int SIMULATION_STEPS = 200;
const int LANDMARK_COUNT = 20;
const int BLOCK_STEPS = 5;
const int VIEW_RANGE = 2; // Range in number of steps
const double LANDMARK_VIEW_RANGE = 5; // Euclidean range for seeing landmarks
const int LOOP_CLOSURE_AGE = 50; // How far back to look for loop closure
                                 // poses younger than this are not considered
const double PROB_LOOP = 0.25; // Probability of including a loop closure
const int LOOP_CLOSURE_MAX = 2; // Maximum number of loop closures included at each step

enum Directions {NORTH=1,EAST=2,SOUTH=3,WEST=4};
enum Actions {FORWARD=1,LEFT=2,RIGHT=3,BACKWARD=4};

// sample from a normal distribution
#include <boost/random/linear_congruential.hpp>
#include <boost/random/normal_distribution.hpp>
#include <boost/random/variate_generator.hpp>
#include <boost/random/uniform_int.hpp>
#include <boost/random/uniform_real.hpp>
#include <boost/random/mersenne_twister.hpp>

typedef boost::mt19937 rnd_generator;
static rnd_generator generator(27u);
//static boost::minstd_rand generator(27u);

// sigma: x,y,th (radians)
const double sigmas[3] = {0.1, 0.1, 0.04};
double landmark_sigmas[2] = {0.1, 0.1};

// sigmas for torus (x,y,z, yaw,pitch,roll)
const double sigmas_3d[6] = {0.05, 0.05, 0.01, 0.01, 0.005, 0.005};
double landmark_sigmas_3d[3] = {0.1, 0.1, 0.1};

// CDF for directions (forward, left, right, backward
//const double dir_prob[4] = {0.5, 0.75, 1.0, 1.0};
//const double dir_prob[4] = {0.8, 0.9, 1.0, 1.0};
const double dir_prob[4] = {0.6, 0.82, 1.0, 1.0};

class Vehicle
{
public:
  Vehicle() : id(0), i(0), j(0), x(0,0,0) {}
  int id;
  int i,j;  // 2D position on the grid
  int d;
  Pose2d x;
};

// Contains the citymap, index by (i,j)
vector<Pose2d> poses;
map<int, std::map<int, std::vector<Vehicle> > > citymap;
vector<Point2d> landmarkmap;

double sample_normal(double sigma = 1.0) {
  typedef boost::normal_distribution<double> Normal;
  Normal dist(0.0, sigma);
  boost::variate_generator<rnd_generator&, Normal> norm(generator, dist);
  return(norm());
}

Pose3d to_3d(const Pose2d& p) {
  if (FLAT_3D) {
    return Pose3d(p.x(),p.y(),0., p.t(),0.,0.);
  } else {
    // convert 2D coordinate [-PI,PI)^2 to 3D coordinate on surface of torus
    const double R = 10;
    const double r = 6;
    double u = p.x()*PI/HEIGHT;
    double v = p.y()*PI/HEIGHT;
    double x = (R+r*cos(v))*cos(u);
    double y = (R+r*cos(v))*sin(u);
    double z = r*sin(v);
    Matrix3d wRo;
    wRo <<
      -sin(v)*cos(u), sin(u), cos(v)*cos(u),
      -sin(v)*sin(u), -cos(u), cos(v)*sin(u),
      cos(v), 0, sin(v);
    Matrix3d oRt;
    double theta = p.t()-PI/2.;
    oRt <<
      cos(theta), -sin(theta), 0.,
      sin(theta), cos(theta), 0.,
      0., 0., 1.;
    double yaw, pitch, roll;
    Rot3d::wRo_to_euler(wRo*oRt, yaw, pitch, roll);
    return Pose3d(x,y,z, yaw,pitch,roll);
  }
}

void write_constraint(int id0, int id1, const Pose2d& delta_) {
  if (!(TORUS||FLAT_3D)) {
    Pose2d delta = delta_;
    if (ADD_NOISE) {
      // corrupt measurement with Gaussian noise
      VectorXd v = delta.vector();
      for (int i=0; i<3; i++) {
        v(i) += sample_normal(sigmas[i]);
      }
      delta.set(v);
    }
    printf("EDGE2 %i %i %g %g %g", id0, id1,
           delta.x(), delta.y(), delta.t());

    for (int i=0; i<3; i++) {
      for (int j=i; j<3; j++) {
        printf(" %g", (i==j)?(1./sigmas[i]):0.);
      }
    }
    printf("\n");
  } else {
    Pose3d pose1 = to_3d(poses[id0]);
    Pose3d pose2 = to_3d(poses[id1]);
    Pose3d delta = pose2.ominus(pose1);
    if (ADD_NOISE) {
      VectorXd v = delta.vector();
      for (int i=0; i<6; i++) {
        v(i) += sample_normal(sigmas_3d[i]);
      }
      delta.set(v);
    }
    // note: order roll/pitch/yaw
    printf("EDGE3 %i %i %g %g %g %g %g %g", id0, id1,
           delta.x(), delta.y(), delta.z(), delta.roll(), delta.pitch(), delta.yaw());
    for (int i=0; i<6; i++) {
      for (int j=i; j<6; j++) {
        printf(" %g", (i==j)?(1./sigmas_3d[(i<=2)?i:8-i]):0.);
      }
    }
    printf("\n");
  }
}

void find_loop_closure(Vehicle & v)
{
  boost::uniform_real<> uni_dist(0,1); 
  boost::variate_generator<rnd_generator&, boost::uniform_real<> > uni(generator, uni_dist);

  int loop = 0; // Number of loop closurers included
  
  for (int i=v.i-VIEW_RANGE; i<=v.i+VIEW_RANGE; i++) {
    std::map<int, std::vector<Vehicle> > & row = citymap[i];
    for (int j=v.j-VIEW_RANGE; j<v.j+VIEW_RANGE; j++) {
      if (row.find(j) != row.end()) {
        std::vector<Vehicle> & col = row[j];
        for (size_t k=0; k<col.size(); k++) {
          // Do not match to recent poses
          if (v.id - col[k].id < LOOP_CLOSURE_AGE) continue;
          if (uni() > PROB_LOOP) continue;

          if (v.id > col[k].id) {
            Pose2d d = v.x.ominus(col[k].x);
            write_constraint(col[k].id, v.id, d);
          } else {
            Pose2d d = col[k].x.ominus(v.x);
            write_constraint(v.id, col[k].id, d);
          }
          loop++;
          if (loop >= LOOP_CLOSURE_MAX) return;
        }
      }
    }
  } 
}

void find_landmarks(Vehicle & v)
{
  for (size_t i=0;i<landmarkmap.size();i++)
  {
    Point2d & l = landmarkmap[i];
    double dx = l.x()-v.x.x();
    double dy = l.y()-v.x.y();
    if ((dx*dx + dy*dy) > LANDMARK_VIEW_RANGE*LANDMARK_VIEW_RANGE) continue;
    
    int id_x = v.id;
    int id_l = i;

    if (!(TORUS||FLAT_3D)) {
      Point2d z = v.x.transform_to(l);
    
      double x,y;
      x = z.x();
      y = z.y();
    
      if (ADD_NOISE) {
        x = x + sample_normal(landmark_sigmas[0]);
        y = y + sample_normal(landmark_sigmas[1]);
      }
    
      printf("LANDMARK %i %i %g %g %g %g %g\n", id_x, id_l,x,y,
             1./landmark_sigmas[0], 0.0, 1./landmark_sigmas[0]);
    } else {
      Pose3d pose = to_3d(v.x);
      Point3d landmark = to_3d(Pose2d(l.x(), l.y(), 0.)).trans();
      Point3d m = pose.transform_to(landmark);
      double x = m.x();
      double y = m.y();
      double z = m.z();
      if (ADD_NOISE) {
        x += sample_normal(landmark_sigmas_3d[0]);
        y += sample_normal(landmark_sigmas_3d[1]);
        z += sample_normal(landmark_sigmas_3d[2]);
      }
      printf("POINT3 %i %i %g %g %g", id_x, id_l, x, y, z);
      for (int i=0; i<3; i++) {
        for (int j=i; j<3; j++) {
          printf(" %g", (i==j)?(1./landmark_sigmas_3d[i]):0.);
        }
      }
      printf("\n");
    }
  }
}

int main(int argc, char** argv)
{
  Vehicle v;
  v.x.set(0,0,-M_PI/2.0);

  poses.push_back(v.x);
  citymap[v.i][v.j].push_back(v);

  generator.seed(static_cast<unsigned int>(std::time(0)));
  generator.seed(static_cast<unsigned int>(1976));

  boost::uniform_int<> four(1,4); // pick direction (N,E,S,W)
  boost::uniform_real<> uni_dist(0,1); 
  boost::variate_generator<rnd_generator&, boost::uniform_int<> > direction(generator, four);
  boost::variate_generator<rnd_generator&, boost::uniform_real<> > action(generator, uni_dist);
  int lastDirection = 1; // Default direction is North
  
  for (int i=0; i<LANDMARK_COUNT; i++)
  {
    boost::variate_generator<rnd_generator&, boost::uniform_real<> > uni(generator, uni_dist);
    int x = (int)(uni()*2.0*((int)WIDTH/BLOCK_STEPS))*BLOCK_STEPS - WIDTH + BLOCK_STEPS/2;
    int y = (int)(uni()*2.0*((int)HEIGHT/BLOCK_STEPS))*BLOCK_STEPS - HEIGHT + BLOCK_STEPS/2;
    
    landmarkmap.push_back(Point2d(x,y));
  }
  
  for (int i=0; i<SIMULATION_STEPS; i++)
  {
    // Pick direction
    int dir;

    if (DIRECTION_SAMPLING == 2) {
      double act = action();
      if (act <= dir_prob[0]) {
        // forward
        dir = lastDirection;
      } else if (act <= dir_prob[1]) {
        // left
        dir = ((lastDirection - 1) - 1 + 4) % 4 + 1;
      } else if (act <= dir_prob[2]) {
        // right
        dir = ((lastDirection + 1) - 1 + 4) % 4 + 1;
      } else {
          // backward
        dir = ((lastDirection + 2) - 1 + 4) % 4 + 1;
      }     
    } else {
      dir = direction();
    }

    if (!TORUS) {
      // Check boundary
      if (dir == NORTH && v.i >=  HEIGHT) continue;
      if (dir == SOUTH && v.i <= -HEIGHT) continue;
      if (dir == EAST && v.j <= -WIDTH) continue;
      if (dir == WEST && v.j >=  WIDTH) continue;
    }

    // Always traverse a whole block
    for (int k=0; k<BLOCK_STEPS; k++)
    {
      // Move
      //  move to new location
      Pose2d d;

      if (lastDirection != dir) {
        switch (dir) {
          case NORTH:
            d.set(0.0, 0.0, 0);
            break;
          case SOUTH:
            d.set(0.0, 0.0, M_PI);
            break;
          case EAST:
            d.set(0.0, 0.0, -M_PI/2.0);
            break;
          case WEST:
            d.set(0.0, 0.0, M_PI/2.0);
            break;
        }
        k = k - 1; // add an extra iteration for the heading check
        Pose2d b(0,0,v.x.t());
        d = d.ominus(b); // represent direction in vehicle frame
      } else {
        d.set(1.0, 0.0, 0);
      }
      lastDirection = dir;

      v.x = v.x.oplus(d);
      if (TORUS) {
        // wrapping around
        if (v.x.x() >=  HEIGHT) v.x.set_x(v.x.x() - 2*HEIGHT);
        if (v.x.x() <  -HEIGHT) v.x.set_x(v.x.x() + 2*HEIGHT);
        if (v.x.y() <  -WIDTH) v.x.set_y(v.x.y() + 2*WIDTH);
        if (v.x.y() >=  WIDTH) v.x.set_y(v.x.y() - 2*WIDTH);
      }
      v.i = (int)v.x.x();
      v.j = (int)v.x.y();
      v.id++;

      poses.push_back(v.x);

      //  write out odometry constraint
      write_constraint(v.id-1, v.id, d);

      // Look for loop closures
      //  find poses close by 
      //  write loop closure constraints

      if (USE_LOOP_CLOSURE) find_loop_closure(v);
      if (USE_LANDMARKS) find_landmarks(v);
      
      // add current pose to map
      citymap[v.i][v.j].push_back(v);
    }
  }

  return 0;
}

