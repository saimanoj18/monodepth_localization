/**
 * @file evaluation.cpp
 * @brief Automated SLAM evaluation system.
 * @author Michael Kaess
 * @version $Id: evaluation.cpp 3659 2011-01-01 21:13:43Z kaess $
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>

#include <iostream>
#include <sstream>
#include <fstream>

#include <vector>
#include <list>

#if 0
#include <boost/iostreams/stream.hpp>
#include <boost/iostreams/device/file_descriptor.hpp>
namespace bio = boost::iostreams;
#endif

#include <sys/time.h>
double tic() {
  struct timeval t;
  gettimeofday(&t, NULL);
  return ((double)t.tv_sec + ((double)t.tv_usec)/1000000.);
}
double toc(double t) {
  double dt = tic() - t;
  return ((dt>0.)?dt:0.);
}

using namespace std;

const char* logfile_name = "/dev/stdout";

class Evaluation {

  int pipe_in;
  int pipe_out;

//  bio::stream<bio::file_descriptor_source>* pipe_in_fds;

  vector<string> data;

  int child_pid;

public:

  // Constructor: initialize some variables
  Evaluation() : pipe_in(-1), pipe_out(-1) {
  }

  ~Evaluation() {
    if (pipe_out>-1) {
      close(pipe_out);
    }
    if (pipe_in>-1) {
      close(pipe_in);
    }
  }

  // Read data file
  void read_data(const char* fname) {
    ifstream infile;
    infile.open (fname, ifstream::in);
    while (infile.good()) {
      string line;
      getline(infile, line);
      line = line + "\n";
      data.push_back(line);
    }
    infile.close();
  }

  // Start SLAM executable and provide file descriptors for reading
  // and writing its standard input and output
  void start_slam(const char* slam_name) {
    int outfd[2];
    int infd[2];

    // create two unidirectional pipes to achieve bi-directional
    // communication with child process / SLAM executable

    if (pipe(outfd) == -1) { // write to this
      perror("Could not create pipe");
      exit(1);
    }
    if (pipe(infd) == -1) { // read from this
      perror("Could not create pipe");
      exit(1);
    }

    child_pid = fork();
    if (!child_pid) {

      // child process, runs the SLAM executable

      close(STDOUT_FILENO);
      close(STDIN_FILENO);

      dup2(outfd[0], STDIN_FILENO);
      dup2(infd[1], STDOUT_FILENO);

      close(outfd[0]);
      close(outfd[1]);
      close(infd[0]);
      close(infd[1]);

      if (system(slam_name) == -1) {
        perror("Could not execute command (system)");
        exit(1);
      }

      exit(0); // todo: what to do when SLAM executable stops?

    } else {

      // original process

      close(outfd[0]);
      close(infd[1]);

      pipe_out = outfd[1];
      pipe_in = infd[0];

      // wrap the file descriptor in a stream to avoid having to deal
      // with the low level buffer stuff to assemble lines
//      pipe_in_fds = new (bio::stream<bio::file_descriptor_source>)(bio::file_descriptor_source(pipe_in), 0);

    }
  }

  void stop_slam() {
    // todo: should terminate SLAM executable, but couldn't figure out
    // how to do this: killing child_pid doesn't work (system creates
    // another child process)
    killpg(0, SIGTERM);
  }

  unsigned int find_step(unsigned int previous) {
    istringstream iss(data[previous]);
    string _command;
    unsigned int _id1, _id2;
    iss >> _command >> _id1 >> _id2;

    unsigned int next = previous;
    string command;
    unsigned int id1;
    unsigned int id2 = _id2;
    while (id2 <= _id2 && data.size()>next+1) {
      next++;
      istringstream iss(data[next]);
      iss >> command >> id1 >> id2;
    }
    if (next == previous) {
      next = 0; // end of data
    }
    return next;
  }

  void send_constraints(FILE* logfile, int start = -1, int end = -1) {
    if (start==-1) { // send all
      start = 0;
      end = data.size()-1;
    }

    // write data to SLAM executable
    for (int i=start; i<=end; i++) {
      string line;
      if (i==end) {
        line = "SOLVE\n";
      } else {
        line = data[i];
      }
      int num = line.length();
      if (write(pipe_out, line.c_str(), num) != num) {
        perror("write failed");
        exit(1);
      }
      // also add to log file
      fprintf(logfile, "%s", line.c_str());
    }
  }

  static const int BUF_SIZE = 100000;
  char line[BUF_SIZE+2];

  void receive_result(FILE* logfile) {
    double t0 = tic();

    // read results from SLAM executable
    // getline(*pipe_in_fds, line) was much more elegant, but terribly slow
    int n = 0;
    while(true) {
      int num = 0;
      if ((num = read(pipe_in, &line[n], BUF_SIZE-n)) > 0) {
        n += num;
        if (strncmp(&line[n-4], "END", 3)==0) {
          break;
        }
        // once there is enough data, write out part of buffer to make space for longer responses
        if (n>BUF_SIZE/2) {
          // have to keep last few characters, as they might already contain parts of "END" string
          const int LAST_N = 4;
          char tmp[LAST_N];
          memcpy(tmp, &line[n-LAST_N], LAST_N);
          line[n-LAST_N] = 0; // terminate string
          fprintf(logfile, "%s", line);
          memcpy(line, tmp, LAST_N);
          n = LAST_N;
        }
      } else {
        usleep(100);
      }
    }
    line[n-4] = 0; // terminate string before "END\n"
    fprintf(logfile, "%s", line);

    // add END/time entry to log
    double time = toc(t0);
    ostringstream tmp;
    tmp << time;
    fprintf(logfile, "END %s\n", tmp.str().c_str());

    fflush(logfile); // force writing now to not influence timing of following steps
  }

};


int main(int argc, char* argv[]) {

  if (argc != 4) {
    cerr << "Usage: evaluation {SLAM_executable} {data_file} {0=batch;1=incr}" << endl;
    exit(1);
  }

  Evaluation eval;

  eval.read_data(argv[2]);

  eval.start_slam(argv[1]);

  FILE* logfile = fopen(logfile_name, "w");
  // todo: optionally save ground truth information into logfile if available

  int i = atoi(argv[3]);
  if (i==0) {
    cerr << "Batch evaluation";
    eval.send_constraints(logfile);
    eval.receive_result(logfile);
  } else {
    cerr << "Incremental evaluation";
    unsigned int previous = 0;
    unsigned int next = 0;
    unsigned int step = 0;
    while ((next = eval.find_step(previous)) > 0) {
      eval.send_constraints(logfile, previous, next);
      eval.receive_result(logfile);
      if (step % 50 == 0) {
        cerr << endl << step;
      } else {
        cerr << ".";
      }
      previous = next;
      step++;
    }
  }
  cerr << endl << "done" << endl;

  fflush(stdout);

  fclose(logfile);

  eval.stop_slam();

  return 0;
}
