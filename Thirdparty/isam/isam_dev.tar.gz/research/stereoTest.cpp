/**
 * @file stereoTest.cpp
 * @brief Test stereo code.
 * @author Michael Kaess
 * @version $Id: stereoTest.cpp 6335 2012-03-22 23:13:52Z kaess $
 */

#include <isam/isam.h>
#include <isam/slam_stereo.h>

using namespace std;
using namespace isam;
using namespace Eigen;

const double f = 370;
const double u0 = 270;
const double v0 = 193;
const double b = 0.12;

void basic_tests() {
  cout << "basic tests:" << endl;

  Pose3d x0;
  Vector2d pp(u0, v0);
  StereoCamera camera(f, pp, b);

  Point3dh p0(4., 6., 8., 0.); //(2., 3., 4., 1.);
  cout << p0 << endl;
  StereoMeasurement s = camera.project(x0, p0);
  cout << s << endl;
  Point3dh p0_ = camera.backproject(x0, s);
  cout << p0_ << endl;
  cout << p0_.to_point3d() << endl;
}

void simple_optimization() {

  cout << "testing optimization" << endl;

  Pose3d x0; // initialized to origin
  Vector2d pp(u0, v0);
  StereoCamera camera(f, pp, b);
  Point3dh p0(4., 6., 8., 2.); // point (2,3,4)

  Slam slam;

  // first camera
  Pose3d_Node* pose0 = new Pose3d_Node();
  slam.add_node(pose0);

  // create a prior on the camera position
  Noise noise6 = Information(100. * eye(6));
  Pose3d_Factor* prior = new Pose3d_Factor(pose0, x0, noise6);
  slam.add_factor(prior);

  // add some stereo measurements
  Point3dh_Node* point0 = new Point3dh_Node();
  slam.add_node(point0);
  StereoMeasurement measurement = camera.project(x0, p0);
  Noise noise3 = Information(eye(3));
  Stereo_Factor* factor1 = new Stereo_Factor(pose0, point0, &camera, measurement, noise3);
  slam.add_factor(factor1);

  slam.update();
  slam.batch_optimization();

  cout << point0->value() << endl;
  cout << point0->value().to_point3d() << endl;
  cout << pose0->value() << endl;
}

int main() {

  basic_tests();

  simple_optimization();

  return 0;
}
