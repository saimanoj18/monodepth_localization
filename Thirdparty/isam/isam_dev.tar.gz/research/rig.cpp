/**
 * @file rig.cpp
 * @brief Rig calibration
 * @author Michael Kaess
 * @version $Id: rig.cpp 6368 2012-03-28 23:01:19Z kaess $
 */

#include <vector>
#include <iostream>

#include <Eigen/Dense>

#include <isam/isam.h>

using namespace std;
using namespace isam;
using namespace Eigen;

vector<Pose3d> poses;
vector<Pose3d> odo;

class Pose3d_Calib_Factor : public FactorT<Pose3d> {
  Pose3d_Node* _pose;
  Pose3d_Node* _delta;

public:

  /**
   * Constructor.
   * @param pose The pose node the prior acts on.
   * @param delta Offset added to prior measurement.
   * @param prior The actual prior measurement.
   * @param noise The 6x6 square root information matrix (upper triangular).
   */
  Pose3d_Calib_Factor(Pose3d_Node* pose, Pose3d_Node* delta, const Pose3d& prior, const Noise& noise)
    : FactorT<Pose3d>("Pose3d_Calib_Factor", 6, noise, prior), _pose(pose), _delta(delta) {
    _nodes.resize(2);
    _nodes[0] = pose;
    _nodes[1] = delta;
  }

  void initialize() {
    if (!_pose->initialized()) {
      Pose3d predict = _measure;
      _pose->init(predict);
    }
  }

  Eigen::VectorXd basic_error(Selector s = ESTIMATE) const {
    Pose3d predicted = _pose->value(s).oplus(_delta->value(s));
    Eigen::VectorXd err = predicted.vector() - _measure.vector();
    err(3) = standardRad(err(3));
    err(4) = standardRad(err(4));
    err(5) = standardRad(err(5));
    return err;
  }
};


void load() {
  FILE* _in = fopen("sync_bb2.txt", "r");
  if (!_in) {
    printf("Cannot open file\n");
    exit(1);
  }
  int i = 0;
  double x, y, z, R, P, Y, dx, dy, dz, dR, dP, dY;
  while (!feof(_in)) {
    char str[2000];
    if (fgets(str, 2000, _in)) {
      int res = sscanf(str, "%lg %lg %lg %lg %lg %lg %lg %lg %lg %lg %lg %lg",
          &x, &y, &z, &R, &P, &Y, &dx, &dy, &dz, &dR, &dP, &dY);
      if (res!=12) {
        printf("Error parsing line\n");
        exit(1);
      }
      poses.push_back(Pose3d(x,y,z,Y,P,R));
      odo.push_back(Pose3d(dx,dy,dz,dY,dP,dR));
    }
    i++;
  }
  fclose(_in);
}

vector<Pose3d_Node*> pose_nodes;

void calibrate() {
  Noise noise_vicon = SqrtInformation(100. * eye(6));
  Noise noise_odo   = SqrtInformation(100. * eye(6));
  Slam slam;
  Pose3d_Node* delta = new Pose3d_Node();
  delta->init(Pose3d());
  slam.add_node(delta);
  for (unsigned int i=0; i<poses.size(); i++) {
    Pose3d_Node* pose = new Pose3d_Node();
    pose_nodes.push_back(pose);
    slam.add_node(pose);
    Pose3d_Calib_Factor* factor = new Pose3d_Calib_Factor(pose, delta, poses[i], noise_vicon);
    slam.add_factor(factor);
    if (i>0) {
      Pose3d_Pose3d_Factor* constraint = new Pose3d_Pose3d_Factor(pose_nodes[i-1], pose, odo[i-1], noise_odo);
      slam.add_factor(constraint);
    }
  }
  Properties p;
  p.method = LEVENBERG_MARQUARDT;
  slam.set_properties(p);
  slam.batch_optimization();

  cout << delta->value() << endl << Pose3d(delta->value().oTw()) << endl;
}

// matlab: 0.1191   -0.0125    0.0058    0.0246   -0.1015   -0.1595
// this: (0.109603, -0.000989498, -0.0409661; -0.147614, -0.0835496, 0.0657769) YPR!!

// provides transformation Tbv from vicon to bumblebee

int main() {
  load();

  printf("loaded %li poses\n", poses.size());

  calibrate();
}
