/**
 * @file generateData.cpp
 * @brief Create 3D simulation data.
 * @author Michael Kaess
 * @version $Id: generateData.cpp 5960 2012-01-23 00:27:20Z kaess $
 */


#include <stdio.h>

#include <isam/Pose3d.h>

using namespace std;
using namespace isam;
using namespace Eigen;

const bool GENERATE_SPHERE = true;
const bool ADD_NOISE = true;
const bool LOOP_CLOSING = true;
// vehicle on surface of sphere, instead of upright (pitch=roll=0)
const bool PERPENDICULAR = true;
const bool CAUCHY_NOISE = true;


// sample from a normal distribution
#include <boost/random/linear_congruential.hpp>
#include <boost/random/normal_distribution.hpp>
#include <boost/random/uniform_real.hpp>
#include <boost/random/variate_generator.hpp>
static boost::minstd_rand generator(27u);
double sample_normal(double sigma = 1.0, double x0 = 0.0) {
  typedef boost::normal_distribution<double> Normal;
  Normal dist(x0, sigma);
  boost::variate_generator<boost::minstd_rand&, Normal> norm(generator, dist);
  return(norm());
}

// sample from a Cauchy distribution
double sample_cauchy(double lambda = 1.0, double x0 = 0.0) {
  boost::uniform_real<> uni_dist(-0.5*M_PI, 0.5*M_PI);
  boost::variate_generator<boost::minstd_rand&, boost::uniform_real<> > uniform(generator, uni_dist);
  double x = x0 + lambda*tan(uniform());
  return x;
}

//const double sigmas[6] = {0.1, 0.1, 0.1, 0.04, 0.01, 0.01};
//const double sigmas[6] = {0.001, 0.001, 0.001, 0.0004, 0.0001, 0.0001};
const double sigmas[6] = {0.001, 0.001, 0.001, 0.001, 0.001, 0.001};

void write_constraint(int id0, int id1, const Pose3d& delta_) {
  Pose3d delta = delta_;
  if (ADD_NOISE) {
    // corrupt measurement with Gaussian noise
    VectorXd v = delta.vector();
    for (int i=0; i<6; i++) {
      if (CAUCHY_NOISE) {
        v(i) += sample_cauchy(sigmas[i]);
      } else {
        v(i) += sample_normal(sigmas[i]);
      }
    }
    delta.set(v);
  }
  // X Y Z roll pitch yaw
  printf("EDGE3 %i %i %g %g %g %g %g %g", id0, id1,
      delta.x(), delta.y(), delta.z(), delta.roll(), delta.pitch(), delta.yaw());
  for (int i=0; i<6; i++) {
    for (int j=i; j<6; j++) {
      double sqrtinf = 0.;
      // only diagonal entries populated
      if (i==j) {
        // roll,pitch,yaw order
        if (i<3) {
          sqrtinf = 1./sigmas[i];
        } else {
          sqrtinf = 1./sigmas[8-i];
        }
      }
      printf(" %g", sqrtinf);
    }
  }
  printf("\n");
}

void add_constraint(Pose3d* poses, int id0, int id1) {
  Pose3d delta = poses[id1].ominus(poses[id0]);
  write_constraint(id0, id1, delta);
}

int main(int argc, const char* argv[]) {
  if (!GENERATE_SPHERE) {
    // generate simple trajectory
    for (int i=0; i<1000; i++) {
      Pose3d delta(0.2, 0., 0.,  0.2, 0., 0.);
      write_constraint(i, i+1, delta);
    }
  } else {
    // generate poses on the surface of a sphere
    const int steps = 50; // number of poses for one turn around the sphere
    const int slices = 50; // number of rounds around the sphere
    const double radius0 = 2.; // starting radius
    const double radius = 50.; // sphere radius

    int n = steps*slices;
    Pose3d poses[n];
    int pose_id = 0;
    // current vertical angle for elevation/slice (starting angle and increment)
    double alpha = atan(radius0/radius);
    double d_alpha = (M_PI-2*alpha) / (double)(n);
    // angle in horizontal plane (starting angle and increment)
    double phi = 0.;
    double d_phi = 2*M_PI / (double)steps;
    for (int i=0; i<steps; i++) {
      for (int j=0; j<slices; j++) {
        // calculate position
        double r = radius * sin(alpha);
        double h = sqrt(radius*radius - r*r);
        // bottom half of sphere?
        if (i<(slices/2)) h = -h;
        // calculate pose
        double y = r * sin(phi);
        double x = r * cos(phi);
        double z = -(radius + h);
        double yaw = phi + M_PI/2.0;
        double roll = 0.;
        if (PERPENDICULAR) {
          roll = alpha;
        }
        // generate measurements
        poses[pose_id] = Pose3d(x,y,z, yaw,0.,roll);
        if (pose_id>0) {
          add_constraint(poses, pose_id-1, pose_id);
          if (LOOP_CLOSING) {
            if (pose_id >= steps) {
              add_constraint(poses, pose_id-steps, pose_id);
            }
          }
        }
        // update for next step
        alpha += d_alpha;
        phi += d_phi;
        pose_id++;
      }
    }
  }
  return 0;
}
