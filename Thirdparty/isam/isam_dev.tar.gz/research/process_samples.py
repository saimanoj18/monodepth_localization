import sys
import os
import subprocess
import smtplib
import re
import time
import email_utils
import time_util

#parse the output of the iSAM executable and return a two-element list
def parse_isam_output(outstring):
    #First, find the elapsed computation time.
    begin = outstring.find("Accumulated computation time: ")
    end = outstring.find('s', begin);
    span = outstring[begin+30:end]
    elapsed_time = re.sub("[^\d.+eE]", "", span)

    #Now find the normalized chi-square 
    begin = outstring.find("Normalized chi-square value: ")
    end = outstring.find('W', begin);
    span = outstring[begin+29:end]
    normalized_chi_square_value = re.sub("[^\d.+eE]", "", span)

    #Now find the weighted sum of squared errors.
    begin = outstring.find("Weighted sum of squared errors: ")
    end = outstring.find('N', begin)
    span = outstring[begin+32:end]
    weighted_sum_of_squared_errors = re.sub("[^\d.eE+]", "", span)

    return [elapsed_time, normalized_chi_square_value, weighted_sum_of_squared_errors]

def extract_num_iterations(outstring):
    begin = outstring.rfind("Iteration")
    substring = outstring[begin+9:begin+14]
    digits = re.sub("\D", "", substring)  #Remove all non-digit characters from this string
    return digits

def run_command(command, times_array, chi_squares_array, SSE_array, num_iterations_array = None):
    p = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    (output, err) = p.communicate();
    method_failure = False
    if(err == ""):  #If the simulation terminated without error, record the results.
        parsed_output = parse_isam_output(output)
        times_array.append(parsed_output[0])
        chi_squares_array.append(parsed_output[1])
        SSE_array.append(parsed_output[2])
        if(num_iterations_array != None):
            num_iterations_array.append(extract_num_iterations(output))
    else:
        #An error flag was raised; print it out.
        print "Error reported when executing command %s:\n%s" % (command, err)
        #Now check to see if this was due to the Jacobian becoming non-positive definite.
        if(output.find("CHOLMOD warning: matrix not positive definite") > -1):  
            #The failure was due to numerical instability as a result of the Jacobian becoming non-positive definite
            method_failure = True
    return method_failure

def remove_bad_data(array, index):
    if(index == (len(array) - 1)):
        array.pop()
    

#Creates a file with name 'filename' in directory 'outputdir', and then writes in the contents of list 'list_data', one element per line
def write_data(outputdir, filename, list_data):
    outfile = open(os.path.join(outputdir, filename), 'w')
    for s in list_data:
        outfile.write(s + "\n")
    outfile.close()
                   
    



#MAIN EXECUTABLE
if __name__== "__main__":

    #DEFINES
    #location of iSAM executable
    isam = "../bin/isam "
    outputdir = "results"

    #iSAM command strings
    PDL_batch_command = "-BPR "
    GN_batch_command = "-BR "
    LM_batch_command = "-BMR "
    
    PDL_incremental_command = "-PR "
    GN_incremental_command = "-R "
    
    
    #File outputs
    PDL_batch_normalized_chi_squares_file = "PDL_batch_normalized_chi_squares.txt"
    GN_batch_normalized_chi_squares_file = "GN_batch_normalized_chi_squares.txt"
    LM_batch_normalized_chi_squares_file = "LM_batch_normalized_chi_squares.txt"
    
    PDL_batch_elapsed_computation_times_file = "PDL_batch_elapsed_computation_times.txt"
    GN_batch_elapsed_computation_times_file = "GN_batch_elapsed_computation_times.txt"
    LM_batch_elapsed_computation_times_file = "LM_batch_elapsed_computation_times.txt"

    PDL_batch_num_iterations_file = "PDL_batch_num_iterations.txt"
    GN_batch_num_iterations_file = "GN_batch_num_iterations.txt"
    LM_batch_num_iterations_file = "LM_batch_num_iterations.txt"

    PDL_batch_SSE_file = "PDL_batch_SSE.txt"
    GN_batch_SSE_file = "GN_batch_SSE.txt"
    LM_batch_SSE_file = "LM_batch_SSE.txt"
    
    PDL_incremental_normalized_chi_squares_file = "PDL_incremental_normalized_chi_squares.txt"
    GN_incremental_normalized_chi_squares_file = "GN_incremental_normalized_chi_squares.txt"
    
    PDL_incremental_elapsed_computation_times_file = "PDL_incremental_elapsed_computation_times.txt"
    GN_incremental_elapsed_computation_times_file = "GN_incremental_elapsed_computation_times.txt"
    
    PDL_incremental_SSE_file = "PDL_incremental_SSE.txt"
    GN_incremental_SSE_file = "GN_incremental_SSE.txt"
    
    
    #Get the name of the directory in which the files are kept.
    if len(sys.argv) == 1:
        directory = os.getcwd()
    elif len(sys.argv) == 2:
        directory = sys.argv[1]
    else:
        print "Usage:  python " + sys.argv[0] + " <directory of files to process>"
        exit(1);
        
        
    #Create a directory to hold the results.
    if(not os.path.isdir(outputdir)):
        os.mkdir(outputdir)
        
        
    #Now get the list of files in the directory.
    file_list = os.listdir(directory)

    num_files = len(file_list)
        
    print "Found %d files in directory %s " % (num_files, directory)
        
    #Set up some empty lists that will be used to hold various data.
    PDL_batch_normalized_chi_squares = []
    GN_batch_normalized_chi_squares = []
    LM_batch_normalized_chi_squares = []
    
    PDL_batch_elapsed_computation_times = []
    GN_batch_elapsed_computation_times = []
    LM_batch_elapsed_computation_times = []

    PDL_batch_num_iterations = []
    GN_batch_num_iterations = []
    LM_batch_num_iterations = []

    PDL_batch_SSE = []
    GN_batch_SSE = []
    LM_batch_SSE = []
    
    PDL_iterations = []
    GN_iterations = []
    LM_iterations = []
    
    PDL_incremental_normalized_chi_squares = []
    GN_incremental_normalized_chi_squares = []
    
    PDL_incremental_elapsed_computation_times = []
    GN_incremental_elapsed_computation_times = []
    
    PDL_incremental_SSE = []
    GN_incremental_SSE = []


    #Record the number of times each method fails due to the Jacobian becoming non-positive-definite
    PDL_batch_num_failures = 0
    GN_batch_num_failures = 0
    LM_batch_num_failures = 0
    
    PDL_incremental_num_failures = 0
    GN_incremental_num_failures = 0
    
    loop_number = 1

    start_time = time.time()  #Get time at start of file processing
    
    #Now iterate through each of the problem instances.
    for file_name in file_list:

         #First, determine the path + filename of the target file we want to use for this iteration
        file_path = os.path.join(directory, file_name)

        if os.path.isfile(file_path):  #Only try this operation on /files/ within the current directory.
 
            print "Starting loop %d" % loop_number

            #BATCH COMPUTATIONS
            
            #Do the computation with Powell's Dog-Leg
            command = isam +  PDL_batch_command + file_path
            method_failure = run_command(command, PDL_batch_elapsed_computation_times, PDL_batch_normalized_chi_squares, PDL_batch_SSE, PDL_batch_num_iterations)
            if(method_failure):
                PDL_batch_num_failures = PDL_batch_num_failures + 1
            

        
            #Do the computation with Gauss-Newton
            command = isam +  GN_batch_command + file_path
            method_failure = run_command(command, GN_batch_elapsed_computation_times, GN_batch_normalized_chi_squares, GN_batch_SSE, GN_batch_num_iterations)
            if(method_failure):
                GN_batch_num_failures = GN_batch_num_failures + 1
        
            #Do the computation with Levenberg-Marquardt
            command = isam +  LM_batch_command + file_path
            method_failure = run_command(command, LM_batch_elapsed_computation_times, LM_batch_normalized_chi_squares, LM_batch_SSE, LM_batch_num_iterations)
            if(method_failure):
                LM_batch_num_failures = LM_batch_num_failures + 1
        
            #INCREMENTAL COMPUTATIONS
        
            #Do the computation with Powell's Dog-Leg
#            command = isam +  PDL_incremental_command + file_path
#            method_failure = run_command(command, PDL_incremental_elapsed_computation_times, PDL_incremental_normalized_chi_squares, PDL_incremental_SSE)
#            if(method_failure):
#                PDL_incremental_num_failures = PDL_incremental_num_failures + 1
        
            #Do the computation with Gauss-Newton
#            command = isam + GN_incremental_command + file_path
#            method_failure = run_command(command, GN_incremental_elapsed_computation_times, GN_incremental_normalized_chi_squares, GN_incremental_SSE)
#            if(method_failure):
#                GN_incremental_num_failures = GN_incremental_num_failures + 1

            loop_number = loop_number + 1
                    
            
    #Now write out the contents of these lists to various files.

    end_time = time.time()

    #Compute elapsed time (in seconds) that the script has been running
    time_diff = end_time - start_time
 
    time_string = time_util.print_time_string(time_diff)

    process_summary_string = "Processed %d files in %s" % (num_files, time_string)

    print process_summary_string
            
    #Write out the data for PDL batch
    write_data(outputdir, PDL_batch_normalized_chi_squares_file, PDL_batch_normalized_chi_squares)
    write_data(outputdir, PDL_batch_elapsed_computation_times_file, PDL_batch_elapsed_computation_times)
    write_data(outputdir, PDL_batch_num_iterations_file, PDL_batch_num_iterations)
    write_data(outputdir, PDL_batch_SSE_file, PDL_batch_SSE)
            
    #Write out the data for GN batch
    write_data(outputdir, GN_batch_normalized_chi_squares_file, GN_batch_normalized_chi_squares)
    write_data(outputdir, GN_batch_elapsed_computation_times_file, GN_batch_elapsed_computation_times)
    write_data(outputdir, GN_batch_num_iterations_file, GN_batch_num_iterations)
    write_data(outputdir, GN_batch_SSE_file, GN_batch_SSE)

    #Write out the data for LM batch
    write_data(outputdir, LM_batch_normalized_chi_squares_file, LM_batch_normalized_chi_squares)
    write_data(outputdir, LM_batch_elapsed_computation_times_file, LM_batch_elapsed_computation_times)
    write_data(outputdir, LM_batch_num_iterations_file, LM_batch_num_iterations)
    write_data(outputdir, LM_batch_SSE_file, LM_batch_SSE)   
    
    
    #Write out the data for PDL incremental mode
#    write_data(outputdir, PDL_incremental_normalized_chi_squares_file, PDL_incremental_normalized_chi_squares)
#    write_data(outputdir, PDL_incremental_elapsed_computation_times_file, PDL_incremental_elapsed_computation_times)
#    write_data(outputdir, PDL_incremental_SSE_file, PDL_incremental_SSE)
    
    #Write out the data for GN incremental mode
#    write_data(outputdir, GN_incremental_normalized_chi_squares_file, GN_incremental_normalized_chi_squares)
#    write_data(outputdir, GN_incremental_elapsed_computation_times_file, GN_incremental_elapsed_computation_times)
#    write_data(outputdir, GN_incremental_SSE_file, GN_incremental_SSE)


#    failure_string = "Summary of failures due to non-positive-definiteness of Jacobian:\n\n Powell's Dog-Leg (batch mode): %d\nGauss-Newton (batch mode): %d\nLevenberg-Marquardt: %d\nPowell's Dog-Leg (incremental mode): %d\nGauss-Newton (incremental mode): %d\n" % (PDL_batch_num_failures, GN_batch_num_failures, LM_batch_num_failures, PDL_incremental_num_failures, GN_incremental_num_failures)


    print "\n" + process_summary_string +"\n"

    from_address = 'dmrosen@mit.edu'
    to_address = 'dmrosen@mit.edu'

    subject = 'Experiments finished'

    msg_string = "The experiment you were running has successfully completed:\n\n" + process_summary_string + "\n\n" #+ failure_string

    msg = ("From: %s\r\nTo: %s\r\nSubject: %s\r\n\r\n" % (from_address, to_address, subject)) + msg_string


    #email_utils.send_text_message(msg)
    #email_utils.send_notification_email(msg)
