/**
 * @file rig.cpp
 * @brief Rig/IMU calibration
 * @author Michael Kaess
 * @version $Id: rig_imu.cpp 6902 2012-06-26 02:43:17Z kaess $
 */

#include <vector>
#include <iostream>

#include <Eigen/Dense>

#include <isam/isam.h>

using namespace std;
using namespace isam;
using namespace Eigen;

typedef Eigen::Matrix<double, 9, 1> Vector9d;

// gravity in Boston (42 degrees north)
// 9.780327*(1+0.0053024*(sin(deg2rad(42)))^2 - 0.0000058*(sin(deg2rad(2*42)))^2)
//const double gravity_constant = 9.8035; // for Boston
const double gravity_constant = 9.8033; // median from file

// IMU measurement
class IMU {
  friend std::ostream& operator<<(std::ostream& out, const IMU& p) {
    p.write(out);
    return out;
  }

  // time interval
  double _dt;
  // angular velocity
  Point3d _vel;
  // linear acceleration
  Point3d _acc;

public:

  static const int dim = 9;
  static const char* name() {
    return "IMU";
  }

  IMU() : _dt(0), _vel(0,0,0), _acc(0,0,0) {}

  IMU(double dt, double vx, double vy, double vz, double ax, double ay, double az)
  : _dt(dt), _vel(vx, vy, vz), _acc(ax, ay, az) {}

  double dt() const {
    return _dt;
  }

  Vector9d vector() const {
    Vector9d tmp;
    tmp << _vel.x(), _vel.y(), _vel.z(), _acc.x(), _acc.y(), _acc.z(), 0, 0, 0;
    return tmp;
  }

  void write(std::ostream &out) const {
    out << _dt << ": "
        << "ang vel: " << _vel.x() << ", " << _vel.y() << ", " << _vel.z()
        << "; lin acc: " << _acc.x() << ", " << _acc.y() << ", " << _acc.z();
  }
};


// Pose3d with linear velocity added
class Pose3dV : public Pose3d {

  // linear velocity
  Point3d _vel;

public:

  static const int dim = 9;
  static const char* name() {
    return "Pose3dV";
  }

  Pose3dV() : Pose3d(), _vel(0,0,0) {}

  explicit Pose3dV(const Pose3d& t) : Pose3d(t), _vel(0,0,0) {}

  Pose3dV(double x, double y, double z, double yaw, double pitch, double roll) : Pose3d(x, y, z, yaw, pitch, roll), _vel(0,0,0) {}

  Pose3dV(const Eigen::MatrixXd& m) : Pose3d(m), _vel(0,0,0) {}

  Pose3dV(const Point3d& t, const Rot3d& rot) : Pose3d(t, rot), _vel(0,0,0) {}

  Pose3dV exmap(const Vector9d& delta) const {
    Pose3dV res = Pose3dV(this->pose3d().exmap(delta.head(6)));
    res._vel = this->_vel.exmap(delta.tail(3));
    return res;
  }

  Pose3d pose3d() const {
    return Pose3d(trans(), rot());
  }

  Point3d vel() const {
    return _vel;
  }

  Vector9d vector() const {
    Vector9d tmp;
    tmp << pose3d().vector(), _vel.vector();
    return tmp;
  }
};

// Vicon/unknown transform factor
typedef NodeT<Pose3dV> Pose3dV_Node;

// prior on velocity (needed for first pose)
class Pose3dV_Factor : public FactorT<Point3d> {
  Pose3dV_Node* _pose;

public:

  /**
   * Constructor.
   * @param pose The pose node the prior acts on.
   * @param prior The actual prior measurement.
   * @param noise The 6x6 square root information matrix (upper triangular).
   */
  Pose3dV_Factor(Pose3dV_Node* pose, const Point3d& prior, const Noise& noise)
    : FactorT<Point3d>("Pose3dV_Factor", 3, noise, prior), _pose(pose) {
    _nodes.resize(1);
    _nodes[0] = pose;
  }

  void initialize() {
    require (_pose->initialized(), "Pose3dV_Factor cannot initialize pose");
  }

  Eigen::VectorXd basic_error(Selector s = ESTIMATE) const {
    Eigen::VectorXd err = _nodes[0]->vector(s).tail(3) - _measure.vector();
    return err;
  }
};


class Pose3dV_Calib_Factor : public FactorT<Pose3d> {
  Pose3dV_Node* _pose;
  Pose3d_Node* _delta;

public:

  /**
   * Constructor.
   * @param pose The pose node the prior acts on.
   * @param delta Offset added to prior measurement.
   * @param prior The actual prior measurement.
   * @param noise The 6x6 square root information matrix (upper triangular).
   */
  Pose3dV_Calib_Factor(Pose3dV_Node* pose, Pose3d_Node* delta, const Pose3d& prior, const Noise& noise)
    : FactorT<Pose3d>("Pose3dV_Calib_Factor", 6, noise, prior), _pose(pose), _delta(delta) {
    _nodes.resize(2);
    _nodes[0] = pose;
    _nodes[1] = delta;
  }

  void initialize() {
    if (!_pose->initialized()) {
      Pose3dV predict(_delta->value().ominus(_measure));
      _pose->init(predict);
    }
  }

  Eigen::VectorXd basic_error(Selector s = ESTIMATE) const {
    Pose3d predicted = _pose->value(s).oplus(_delta->value(s));
    Vector6d err = predicted.vector() - _measure.vector();
    err(3) = standardRad(err(3));
    err(4) = standardRad(err(4));
    err(5) = standardRad(err(5));
    return err;
  }
};

// IMU measurement factor
class Pose3dV_Pose3dV_IMU_Factor : public FactorT<IMU> {
  Pose3dV_Node* _pose1;
  Pose3dV_Node* _pose2;

public:

  /**
   * Constructor.
   * @param pose1 The pose from which the measurement starts.
   * @param pose2 The pose to which the measurement extends.
   * @param measure The relative measurement from pose1 to pose2 (pose2 in pose1's frame).
   * @param noise The 6x6 square root information matrix (upper triangular).
   * @param anchor1 Optional anchor node for trajectory to which pose1 belongs to.
   * @param anchor2 Optional anchor node for trajectory to which pose2 belongs to.
   */
  Pose3dV_Pose3dV_IMU_Factor(Pose3dV_Node* pose1, Pose3dV_Node* pose2,
      const IMU& measure, const Noise& noise)
  : FactorT<IMU>("Pose3dV_Pose3dV_IMU_Factor", 9, noise, measure), _pose1(pose1), _pose2(pose2) {
    _nodes.resize(2);
    _nodes[0] = pose1;
    _nodes[1] = pose2;
  }

  void initialize() {
    require(_pose1->initialized() && _pose2->initialized(),
        "Pose3dV_Pose3dV_IMU_Factor requires both poses to be initialized");
  }

  Eigen::VectorXd basic_error(Selector s = ESTIMATE) const {
    const Pose3dV& p1 = _pose1->value(s);
    const Pose3dV& p2 = _pose2->value(s);

    // predict IMU measurement from previous and current pose
    double dt = _measure.dt();
    double inv_dt = 1./dt;

    // rotation
    double yaw, pitch, roll;
    Eigen::Matrix3d delta_rot = p1.rot().oRw() * p2.rot().wRo();
    Rot3d::wRo_to_euler(delta_rot, yaw, pitch, roll);
    Eigen::Vector3d dr(roll, pitch, yaw);
    Eigen::Vector3d predicted_rot = dr*inv_dt;
    predicted_rot(0) = standardRad(predicted_rot(0));
    predicted_rot(1) = standardRad(predicted_rot(1));
    predicted_rot(2) = standardRad(predicted_rot(2));

    // velocity
    Eigen::Vector3d v1 = p1.vel().vector();
    Eigen::Vector3d v2 = p2.vel().vector();
    Eigen::Vector3d gravity(0, 0, -gravity_constant);
    Eigen::Vector3d predicted_acc = p2.rot().oRw() * ((v2-v1)*inv_dt + gravity);

    // translation - how to do this? should be a constraint instead of measurement...
    Eigen::Vector3d x1 = p1.trans().vector();
    Eigen::Vector3d x2 = p2.trans().vector();
    Eigen::Vector3d coupling = (x2-x1)*inv_dt;

    // predicted IMU measurements
    Vector9d predicted;
    predicted << predicted_rot, predicted_acc, coupling;

    Vector9d err = predicted - _measure.vector();

    //    cout << _measure << endl << predicted << endl << endl;

    return err;
  }

};

///////////////////////////////////////////////////////////////////////////////////////////

// Vicon poses
vector<Pose3d> poses;
// IMU measurement
vector<IMU> imu;

// IMU trajectory
vector<Pose3dV_Node*> pose_nodes;
vector<Pose3dV_Calib_Factor*> calib_factors;
vector<Pose3dV_Pose3dV_IMU_Factor*> imu_factors;

void load() {
  FILE* _in = fopen("sync_imu.txt", "r");
  if (!_in) {
    printf("Cannot open file\n");
    exit(1);
  }
  int i = 0;
  double dt, x, y, z, W, X, Y, Z, vx, vy, vz, ax, ay, az;
  while (!feof(_in)) {
    char str[2000];
    if (fgets(str, 2000, _in)) {
      int res = sscanf(str, "%lg %lg %lg %lg %lg %lg %lg %lg %lg %lg %lg %lg %lg %lg",
        &dt, &x, &y, &z, &W, &X, &Y, &Z, &vx, &vy, &vz, &ax, &ay, &az);
      if (res!=14) {
        printf("Error parsing line\n");
        exit(1);
      }
      poses.push_back(Pose3d(Point3d(x,y,z),Rot3d(Eigen::Quaterniond(W,X,Y,Z))));
      imu.push_back(IMU(dt, vx,vy,vz, ax,ay,az));
    }
    i++;
  }
  fclose(_in);
}

void calibrate() {
  Slam slam;
  Noise noise_vicon = Covariance(0.005*0.005 * eye(6));  // xyz rpy
  // from data (stationary part at end of sequence)
  // std linear acceleration: x 0.0063, y 0.0058, z 0.0099  (0.01)
  // std angular velocity: r 0.0025, p 0.0026, y 0.0029   (0.003)
  MatrixXd sig = eye(9);
  sig(1,1) = sig(2,2) = sig(3,3) = 0.003;
  sig(4,4) = sig(5,5) = sig(6,6) = 0.01;
  sig(7,7) = sig(8,8) = sig(9,9) = 0.0001; // as small as possible...
  Noise noise_imu   = Covariance(sig*sig);   // vxyz axyz coupling
  Pose3d_Node* delta = new Pose3d_Node();
  delta->init(Pose3d());
  slam.add_node(delta);
#if 1 // prior on delta
  Noise noise_prior = SqrtInformation(1 * eye(6));
  Pose3d prior_delta;
  if (true) {
    prior_delta = Pose3d(-0.104759, -0.01183, 0.0507699, 0.142418, 0.0921642, -0.0530169);
  }
  Pose3d_Factor* prior = new Pose3d_Factor(delta, Pose3d(), noise_prior);
  slam.add_factor(prior);
#endif
  // add each pose with calibration factor to Vicon measurement and inertial factor to previous pose
  unsigned int num = 1000; // todo poses.size();
  unsigned int offset = 1000; // todo
  for (unsigned int i=0; i<num; i++) {
    Pose3dV_Node* pose = new Pose3dV_Node();
    pose_nodes.push_back(pose);
    slam.add_node(pose);
    Pose3dV_Calib_Factor* factor = new Pose3dV_Calib_Factor(pose, delta, poses[i+offset], noise_vicon);
    calib_factors.push_back(factor);
    slam.add_factor(factor);
    if (i==0) {
#if 1      // prior on velocity for first pose
      Noise noise_priorv = SqrtInformation(10. * eye(3));
      Pose3dV_Factor* priorv = new Pose3dV_Factor(pose, Point3d(), noise_priorv);
      slam.add_factor(priorv);
#endif
    } else {
      Pose3dV_Pose3dV_IMU_Factor* constraint = new Pose3dV_Pose3dV_IMU_Factor(pose_nodes[i-1], pose, imu[i-1], noise_imu);
      imu_factors.push_back(constraint);
      slam.add_factor(constraint);
    }
  }

  Properties p;
//  p.method = LEVENBERG_MARQUARDT;
  p.method = DOG_LEG;
  slam.set_properties(p);

//  cout << imu_factors[0]->jacobian() << endl;
//  cout << calib_factors[0]->jacobian() << endl;

//  slam.jacobian().print(cout);

  slam.batch_optimization();

  cout << delta->value() << endl << Pose3d(delta->value().oTw()) << endl;
}

int main() {
  load();

  printf("loaded %li poses\n", poses.size());

  calibrate();
}
