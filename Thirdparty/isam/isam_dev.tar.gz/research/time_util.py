def print_time_string(elapsed_time_in_seconds):

    #Convert to int to get rid of fractional parts of seconds
    elapsed_time_in_seconds = int(elapsed_time_in_seconds)
    
    hours = elapsed_time_in_seconds // 3600
    minutes = (elapsed_time_in_seconds - 3600 * hours) // 60
    seconds = (elapsed_time_in_seconds - 3600 * hours - 60*minutes)

    minutes_string = ""
    seconds_string = ""

    if(minutes < 10):
        minutes_string = "0%d" % minutes;
    else:
        minutes_string = "%d" % minutes;

    if(seconds < 10):
        seconds_string = "0%d" % seconds;
    else:
        seconds_string = "%d" % seconds;

    hours_string = "%d" % hours;

    time_string = "%s:%s:%s" % (hours_string, minutes_string, seconds_string);

    return time_string;
    
