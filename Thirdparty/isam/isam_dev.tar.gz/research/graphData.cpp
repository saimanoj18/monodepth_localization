/**
 * @file graphData.cpp
 * @brief Reads in a graph and generates a random traversal on that graph.
 * @author Hordur Johannsson
 * @author Michael Kaess
 * @version $Id: graphData.cpp 4111 2011-03-14 03:46:24Z kaess $
 */

#include <fstream>
#include <iostream>
#include <sstream>
#include <ctime>
#include <cstdio>
#include <isam/Pose3d.h>
#include <map>
#include <set>
#include <vector>
#include <algorithm>

#include <boost/random/variate_generator.hpp>
#include <boost/random/uniform_int.hpp>
#include <boost/random/mersenne_twister.hpp>
#include <boost/random/normal_distribution.hpp>
#include <boost/random/uniform_real.hpp>

const bool ADD_NOISE = true;
const double VIEW_RANGE = 2;
const double PROB_LOOP = 0.2; // Probability of including a loop closure
const int LOOP_CLOSURE_AGE = 10;

typedef boost::mt19937 rnd_generator;
static rnd_generator generator(27u);

using namespace std;
using namespace isam;
using namespace Eigen;

#define BUF_SIZE 4096
const double sigmas[3] = {0.02, 0.02, 0.01};


struct PoseNode
{
	PoseNode(int id, Pose2d pose) : id(id), x(pose) {};
	int id;
	Pose2d x;  
};

std::map<int, Pose2d> nodes;
std::map<int, std::vector<int> > edges;
std::vector<PoseNode> poses;

double sample_normal(double sigma = 1.0) {
  typedef boost::normal_distribution<double> Normal;
  Normal dist(0.0, sigma);
  boost::variate_generator<rnd_generator&, Normal> norm(generator, dist);
  return(norm());
}

/**
 * Load the graph
 */
void load_graph(const std::string & filename)
{
	std::fstream file;
	file.open (filename.c_str(), std::fstream::in);  

	char buf[BUF_SIZE];
	while (!file.eof()) 
	{
		file.getline(buf,sizeof(buf));
		std::string l(buf);
		std::stringstream ss(l);
		std::string s;
		ss >> s; // Type
		
		if (s == "VERTEX2") {
//		  std::cout << s << std::endl;
		  int id;
		  double x,y,th;
		  ss >> id;
		  ss >> x;
		  ss >> y;
		  ss >> th;
		  
		  nodes[id] = Pose2d(x,y,th);
		  edges[id] = std::vector<int>(); 
		  
		} else if (s == "EDGE2") {
//		  std::cout << s << std::endl;
		  int id0,id1;
		  ss >> id0;
		  ss >> id1;
		  if (find(edges[id0].begin(),edges[id0].end(),id1) == edges[id0].end()) edges[id0].push_back(id1);
		  if (find(edges[id1].begin(),edges[id1].end(),id0) == edges[id1].end()) edges[id1].push_back(id0);
		}
	}	

	file.close();
}

void write_constraint(int id0, int id1, const Pose2d& delta_) {
  Pose2d delta = delta_;
  if (ADD_NOISE) {
    // corrupt measurement with Gaussian noise
    VectorXd v = delta.vector();
    for (int i=0; i<3; i++) {
      v(i) += sample_normal(sigmas[i]);
    }
    delta.set(v);
  }
  // X Y Z roll pitch yaw
  printf("EDGE2 %i %i %g %g %g", id0, id1,
      delta.x(), delta.y(), delta.t());

  for (int i=0; i<3; i++) {
    for (int j=i; j<3; j++) {
      printf(" %g", (i==j)?(1./(sigmas[i])):0.);
    }
  }
  printf("\n");
}

void find_loop_closure(int poseid, Pose2d pose)
{
	boost::uniform_real<> uni_dist(0,1); 
	boost::variate_generator<rnd_generator&, boost::uniform_real<> > uni(generator, uni_dist);
  
	for (size_t i=0; i<poses.size(); i++)
	{
		double dx = poses[i].x.x() - pose.x();
		double dy = poses[i].x.y() - pose.y();
		
		if ((dx*dx+dy*dy)<VIEW_RANGE)
		{
			if (poseid - poses[i].id < LOOP_CLOSURE_AGE) continue;
			if (uni() > PROB_LOOP) continue;
		  
			write_constraint(poses[i].id,poseid,pose.ominus(poses[i].x));
		}		
	}
}

int main(int argc, char** argv)
{
	generator.seed(static_cast<unsigned int>(std::time(0)));
  
	load_graph("data/beijing/beijingData_trips.graph");
	
	int nodeid = (*nodes.begin()).first;
	
	int poseid = 0;
	Pose2d pose = nodes[nodeid];;
	
	for (int i=0;i<10000;i++)
	{
//		std::cout << nodeid << " " << edges[nodeid].size() << std::endl;
		
		if (edges[nodeid].size() == 0) {
			std::cout << " no edges " << std::endl;
			exit(-1);
		}
		
		boost::uniform_int<> rand_edge(0,edges[nodeid].size()-1);
		boost::variate_generator<rnd_generator&, boost::uniform_int<> > edge(generator, rand_edge);
		
		int nextnodeid = edges[nodeid][edge()];
		
		Pose2d delta = nodes[nextnodeid].ominus(nodes[nodeid]);
		//write_constraint(nodeid,nextnodeid,delta);
		write_constraint(poseid,poseid+1,delta);
		
		poseid++;
		pose = nodes[nextnodeid];
		
		// add
		poses.push_back(PoseNode(poseid,pose));
		
		// find loop closure 
		find_loop_closure(poseid,pose);
		
		nodeid = nextnodeid;		
	}
	
	return 0;
}
