/**
 * @file Node.cpp
 * @brief A single variable node
 * @author Michael Kaess
 * @author Hordur Johannsson
 * @version $Id:  $
 *
 * [insert iSAM license]
 *
 */

#include "isam/Node.h"
#include "isam/Factor.h"

namespace isam
{
void Node::mark_deleted() {
  _deleted = true;
  for (std::list<Factor*>::iterator factor = _factors.begin(); factor != _factors.end(); ++factor)
    (*factor)->mark_deleted();
}
void Node::erase_marked_factors() {
  for (std::list<Factor*>::iterator factor = _factors.begin(); factor != _factors.end();)
    if ((*factor)->deleted()) factor = _factors.erase(factor);
    else ++factor;
}
} // namespace - isam
