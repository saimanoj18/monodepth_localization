/**
 * @file ChowLiuTree.cpp
 * @brief ChowLiuTree for information form Gaussian distributions
 * @author Michael Kaess
 * @author Nicholas Carlevaris-Bianco
 * @version $Id: covariance.cpp 4975 2011-07-13 17:49:09Z kaess $
 *
 * [insert iSAM license]
 *
 */

#include <iostream>

#include <Eigen/LU>

#include "isam/ChowLiuTree.h"
#include "isam/util.h"

using namespace std;
using namespace Eigen;

namespace isam {

MatrixXd matslice (const MatrixXd A, vector<int> ii, vector<int> jj) {
  MatrixXd B(ii.size(), jj.size());
  for (size_t i=0; i<ii.size(); i++) {
    for (size_t j=0; j<jj.size(); j++) {
      B(i,j) = A(ii[i], jj[j]);
    }
  }
  return B;
}

void eig_lowrank (MatrixXd A, MatrixXd &U, MatrixXd &D, double eps = numeric_limits<float>::epsilon()) {

  A = (A.transpose() + A) / 2.0;

  SelfAdjointEigenSolver<MatrixXd> eigensolver(A);
  if (eigensolver.info() != Success) {
    cout << "ERROR: Failed to compute eigenvalue decomposition!" << endl;
    cout << "A:" << endl << A << endl;
  }

  VectorXd d = eigensolver.eigenvalues();
  MatrixXd Ufull = eigensolver.eigenvectors();

  double tol = eps * d.size();

  vector<int> inds_pos;
  for (int i=0; i<d.size(); i++) {
    if (d(i) > tol)
      inds_pos.push_back(i);
  }

  if (0 == inds_pos.size()) {
    U = MatrixXd();
    D = MatrixXd();
    return;
  }

  D = MatrixXd (inds_pos.size(), inds_pos.size());
  D.setZero();
  U = MatrixXd (Ufull.rows(), inds_pos.size());
  for (size_t i=0; i<inds_pos.size(); i++) {
    D(i,i) = d(inds_pos[i]);
    U.col(i) = Ufull.col(inds_pos[i]);
  }

  double recreate_test = (U*D*U.transpose() - A).array().abs().matrix().lpNorm<Infinity>();
  //cout << "[glc]\tEig_Lowrank Recreate Test: " << recreate_test << endl;
  if (recreate_test > 10) {
    cout << "ERROR: Eig_Lowrank Recreate Test Failed!" << endl;
    cout << "A" << endl << A << endl;
  }
}

// cholesky based log_det
double logdet_chol (MatrixXd A) {
  MatrixXd L = A.llt().matrixL();
  double tmp = 0;
  for (int i=0; i<A.rows(); i++) {
    tmp += log (L(i,i));
  }
  return 2.0 * tmp;
}

MatrixXd ChowLiuTreeInfo::marginal(int id) {

  // get the indicies associated with the node
  vector<int> iia(0);
  vector<int> iib(0);
  int off = 0;
  for (size_t i=0; i<nodes.size(); i++) {
    if ((int)i == id)
      for (int j=0; j<nodes[i]->dim(); j++) iia.push_back(off+j);
    else
      for (int j=0; j<nodes[i]->dim(); j++) iib.push_back(off+j);
    off += nodes[i]->dim();
  }

  if (iib.size() > 0) {
    MatrixXd Laa = matslice(L, iia, iia);
    MatrixXd Lbb = matslice(L, iib, iib);
    MatrixXd Lab = matslice(L, iia, iib);
    MatrixXd Lbbinv = posdef_pinv(Lbb);
    return Laa - Lab * Lbbinv * Lab.transpose();
    //return Laa - Lab * Lbb.inverse() * Lab.transpose();
  } else
    return L;
}

MatrixXd ChowLiuTreeInfo::joint(int ida, int idb) {

  vector<int> iia(0);
  vector<int> iib(0);
  vector<int> iic(0);
  int off = 0;
  for (size_t i=0; i<nodes.size(); i++) {
    if ((int)i == ida)
      for (int j=0; j<nodes[i]->dim(); j++) iia.push_back(off+j);
    else if ((int)i == idb)
      for (int j=0; j<nodes[i]->dim(); j++) iib.push_back(off+j);
    else
      for (int j=0; j<nodes[i]->dim(); j++) iic.push_back(off+j);
    off += nodes[i]->dim();
  }
  vector<int> iiab(0);
  iiab.insert(iiab.end(), iia.begin(), iia.end());
  iiab.insert(iiab.end(), iib.begin(), iib.end());
  
  if (iic.size() > 0) {
    MatrixXd Labab = matslice(L, iiab, iiab);
    MatrixXd Lcc = matslice(L, iic, iic);
    MatrixXd Labc = matslice(L, iiab, iic);
    MatrixXd Lccinv = posdef_pinv(Lcc);
    return Labab - Labc * Lccinv * Labc.transpose();
    //return Labab - Labc * Lcc.inverse() * Labc.transpose();
  } else
      return matslice(L, iiab, iiab);
}

MatrixXd ChowLiuTreeInfo::conditional(int ida, int idb) {

  MatrixXd Lj = joint(ida, idb);
  return Lj.block(0, 0, nodes[ida]->dim(), nodes[ida]->dim());

}

void ChowLiuTree::_calc_factors(void) {

    factors.clear();

    map<int, ChowLiuTreeNode>::iterator it;
    for (it=tree.begin(); it!=tree.end(); it++) {

      ChowLiuTreeFactor cltf;

      if (it->second.is_root()) {
        // check for rank zero priors
        SelfAdjointEigenSolver<MatrixXd> eigL(it->second.marginal);
        if (eigL.eigenvalues().maxCoeff() < GLC_EPS){
          continue;
        }
        cltf. L = it->second.marginal;
        cltf.nodes.push_back (_clt_info.nodes[it->second.id]);
      } else {
        cltf.nodes.push_back(_clt_info.nodes[it->second.id]);
        cltf.nodes.push_back(_clt_info.nodes[it->second.pid]);
        int adim = cltf.nodes[0]->dim();
        int bdim = cltf.nodes[1]->dim();
        MatrixXd Lagb = it->second.conditional;
        MatrixXd Lab = it->second.joint;
        MatrixXd Hagb(adim, adim+bdim);
        Hagb.block(0,0,adim,adim) = MatrixXd::Identity (adim,adim);
        MatrixXd Laa = Lab.block(0,0,adim,adim);
        Hagb.block(0,adim,adim,bdim) = posdef_pinv(Laa) * Lab.block(0,adim,adim,bdim);
        cltf.L = Hagb.transpose() * Lagb * Hagb;
      }

      factors.push_back (cltf);
    }
}

bool mi_sort(MI &first, MI &second) {
  return first.mi > second.mi;
}

void
ChowLiuTree::_calc_edges(void)  {

  int nn = _clt_info.num_nodes();
  //double npairs = floor(pow((double)bb, 2.0) / 2) -  floor((double)nn/2);

  for (int i=0; i<nn; i++) {
    for (int j=(i+1); j<nn; j++) {
      MI mi_tmp (i,j, _calc_mi(i, j));
      _edges.push_back(mi_tmp);
    }
  }
  _edges.sort(mi_sort);
  
}

double ChowLiuTree::_calc_mi(int ida, int idb) {

  MatrixXd L_agb = _clt_info.conditional (ida, idb);
  MatrixXd L_a = _clt_info.marginal (ida);

  // use pdet
  //double ldL_agb = plogdet(L_agb);
  //double ldL_a = plogdet(L_a);
  //double mi = 0.5*(ldL_agb - ldL_a);

  // use normal det, must be pinned
  double ldL_agb = log ((L_agb +  MatrixXd::Identity(L_agb.rows(), L_agb.cols())).determinant());
  double ldL_a = log ((L_a +  MatrixXd::Identity(L_a.rows(), L_a.cols())).determinant());
  double mi = 0.5*(ldL_agb - ldL_a);

  return mi;
}

void ChowLiuTree::_max_span_tree(void) {

  // init groups: assign each id to a different group initially
  map<int, int> groups; // map <node index, group index>
  for (int i=0; i<_clt_info.num_nodes(); i++) {
      groups[i] = i;
  }
    
  int group1, group2;
  list<MI>::iterator edge = _edges.begin();
  while(edge != _edges.end()) {
    if(groups[edge->id1] != groups[edge->id2]) {
      group1 = groups[edge->id1];
      group2 = groups[edge->id2];

      // merge group2 into group 1
      map<int, int>::iterator groupIt;
      for(groupIt = groups.begin(); groupIt != groups.end(); groupIt++)
        if(groupIt->second == group2) groupIt->second = group1;

      edge++;
    } else {
      edge = _edges.erase(edge);
    }
  }
  
}

void ChowLiuTree::_build_tree_rec(int id, int pid) {

  ChowLiuTreeNode new_node;

  new_node.id = id;
  new_node.pid = pid;
  new_node.marginal = _clt_info.marginal(id);
  if (pid == -1) {
    new_node.conditional = new_node.marginal;
    new_node.joint = new_node.marginal;
  } else {
    new_node.conditional = _clt_info.conditional(id, pid);
    new_node.joint = _clt_info.joint(id, pid);
  }

  vector<int> cids; // vector of child ids
  list<MI>::iterator edge = _edges.begin();
  while(edge != _edges.end()) {
    if(edge->id1 == new_node.id) {
      cids.push_back(edge->id2);
      edge = _edges.erase(edge);
      continue;
    }
    if(edge->id2 == new_node.id) {
      cids.push_back(edge->id1);
      edge = _edges.erase(edge);
      continue;
    }
    edge++;
  }
  for(size_t i=0; i < cids.size(); i++) {
      new_node.cids.push_back(cids[i]);
      _build_tree_rec(cids[i], new_node.id);
  }

  tree[new_node.id] = new_node;
}


void ChowLiuTree::_update_info(Eigen::MatrixXd L) {

  _clt_info = ChowLiuTreeInfo(L, _clt_info.nodes);
  map<int, ChowLiuTreeNode>::iterator it;
  for (it=tree.begin(); it!=tree.end(); it++) {
    it->second.marginal = _clt_info.marginal(it->second.id);
    if (it->second.is_root()) {
      it->second.conditional = it->second.marginal;
      it->second.joint = it->second.marginal;
    } else {
      it->second.conditional = _clt_info.conditional(it->second.id, it->second.pid);
      it->second.joint = _clt_info.joint(it->second.id, it->second.pid);
    }
  }
  _calc_factors();
}

ChowLiuTree::ChowLiuTree (Eigen::MatrixXd L, std::vector<Node *> nodes)
  : _clt_info(L, nodes)
{
  // make sure we have at least two nodes otherwise return a trival tree
  if (nodes.size() == 1) {

    ChowLiuTreeNode node;
    node.id = 0;
    node.pid = -1;
    node.marginal = _clt_info.marginal(0);
    node.conditional = node.marginal;
    node.joint = node.marginal;
    tree[node.id] = node;
    _calc_factors();
    return; // no sparsification, no need to check if is conservative

  } else {

    //calculate the parent nodes based on maxing mutual information
    _calc_edges();
    _max_span_tree();
    tree.clear();
    _build_tree_rec(_edges.front().id1, -1);
    _calc_factors();

  }

  if (!_is_conservative ()) {
    cout << "[conservative]\tEnsuring a conservative estimate." << endl;
    //_ensure_conservative_ci();
    //_ensure_conservative_wf();
    //_ensure_conservative_wev();
    _ensure_conservative_jv();
  } else {
    cout << "[conservative]\tAlready a conservative estimate." << endl;
  }

}

// -- code for conservative sparsification ---------------------------------------------------

// scale up factor information to same size as target information
MatrixXd ChowLiuTree::_expand_factor_information (const ChowLiuTreeFactor &cltf) {

  int n = _clt_info.L.rows();
  MatrixXd L(n,n);
  L.setZero();

  int ioff = 0;
  int idim = cltf.nodes[0]->dim();
  for (size_t i=0; i<_clt_info.nodes.size(); i++) {
    if (cltf.nodes[0] == _clt_info.nodes[i])
      break;
    else
      ioff += _clt_info.nodes[i]->dim();
  }
  L.block(ioff,ioff,idim,idim) = cltf.L.block(0,0,idim,idim);

  if (cltf.nodes.size() > 1) {
    int joff = 0;
    int jdim = cltf.nodes[1]->dim();
    for (size_t i=0; i<_clt_info.nodes.size(); i++) {
    if (cltf.nodes[1] == _clt_info.nodes[i])
      break;
    else
      joff += _clt_info.nodes[i]->dim();
    }
    L.block(joff,joff,jdim,jdim) = cltf.L.block(idim,idim,jdim,jdim);
    L.block(ioff,joff,idim,jdim) = cltf.L.block(0,idim,idim,jdim);
    L.block(joff,ioff,jdim,idim) = cltf.L.block(idim,0,jdim,idim);
  }
  return L;
}

void ChowLiuTree::_unexpand_factor_information (const MatrixXd &L_full, ChowLiuTreeFactor &cltf) {

  cltf.L.setZero();

  int ioff = 0;
  int idim = cltf.nodes[0]->dim();
  for (size_t i=0; i<_clt_info.nodes.size(); i++) {
    if (cltf.nodes[0] == _clt_info.nodes[i])
      break;
    else
      ioff += _clt_info.nodes[i]->dim();
  }
  cltf.L.block(0,0,idim,idim) = L_full.block(ioff,ioff,idim,idim);

  if (cltf.nodes.size() > 1) {
    int joff = 0;
    int jdim = cltf.nodes[1]->dim();
    for (size_t i=0; i<_clt_info.nodes.size(); i++) {
    if (cltf.nodes[1] == _clt_info.nodes[i])
      break;
    else
      joff += _clt_info.nodes[i]->dim();
    }
    cltf.L.block(idim,idim,jdim,jdim) = L_full.block(joff,joff,jdim,jdim);
    cltf.L.block(0,idim,idim,jdim) = L_full.block(ioff,joff,idim,jdim);
    cltf.L.block(idim,0,jdim,idim) = L_full.block(joff,ioff,jdim,idim);
  }
}

bool ChowLiuTree::_is_conservative (void) {

  MatrixXd Ls (_clt_info.L.rows(), _clt_info.L.rows());
  Ls.setZero();
  for (size_t i=0; i<factors.size(); i++) {
    // expand the information for this factor up to the full size of the factor
    Ls += _expand_factor_information (factors[i]);
  }

  MatrixXd Ps = posdef_pinv(Ls, GLC_EPS);
  MatrixXd P = posdef_pinv(_clt_info.L, GLC_EPS);

  SelfAdjointEigenSolver<MatrixXd> eig(Ps - P);
  if (eig.info() != Success) {
    cout << "ERROR: Failed to computed eig decomposition of consistency constraint: " << endl;
    cout << "L: " << endl << _clt_info.L << endl;
    cout << "Ls: " << endl << Ls << endl;
    exit(EXIT_FAILURE);
  }
  VectorXd d = eig.eigenvalues();
  double min_ev = d.minCoeff();
  cout << "[conservative]\tMin ev of (P_sparse - P) = " << min_ev << endl;
  if (min_ev < -GLC_EPS) {
    return false;
  } else {
    return true;
  }
}

MatrixXd linear_matrix (const vector<MatrixXd> &M, const VectorXd &x) {
  MatrixXd Mofx(M[0].rows(), M[0].cols());
  Mofx.setZero();
  for (int i=0; i<x.size(); i++)
    Mofx += x(i)*M[i];
  return Mofx;
}

// not actually the kld, just the cost function associated with kld
double kld_cost (const VectorXd &x, const VectorXd &c, const MatrixXd &Gx) {
  return c.transpose()*x - logdet_chol(Gx);
}

// -- covariance intersection ----------------------------------------------------------------

// central path for covariance intersection
double cp_ci (const VectorXd &x, const VectorXd &c, const vector<MatrixXd> &G, double t) {
  for (int i=0; i<x.size(); i++){
    if (x(i) <= 0)
      return numeric_limits<double>::max();
  }
  return kld_cost(x, c, linear_matrix(G, x)) - (1.0/t)*x.array().log().sum();
}

// grad and hess of central path for covariance intersection
void diff_cp_ci (VectorXd &g, MatrixXd &H, const VectorXd &x, const VectorXd &c, const vector<MatrixXd> &G, double t) {
  g = VectorXd(x.size());
  H = MatrixXd(x.size(),x.size());
  MatrixXd Gx = linear_matrix(G, x);
  for (int i=0; i<x.size(); i++) {
    MatrixXd inv_Gx_Gi = Gx.llt().solve(G[i]);
    g(i) = c(i) - (inv_Gx_Gi).trace() - (1.0/t)*1.0/x(i);
    for (int j=i; j<x.size(); j++) {
      H(i,j) = (inv_Gx_Gi*Gx.llt().solve(G[j])).trace();
      if (i == j)
        H(i,j) += (1.0/t)*1.0/(x(i)*x(i));
      else
        H(j,i) = H(i,j);
    }
  }
}

void diff_cp_num_ci (VectorXd &g, MatrixXd &H, const VectorXd &x, const VectorXd &c, const vector<MatrixXd> &G, double t) {
  double delta = 1e-6;
  g = VectorXd(x.size());
  H = MatrixXd(x.size(),x.size());
  for (int i=0; i<x.size(); i++) {
    VectorXd xpi = x;
    xpi(i) = xpi(i) + delta;
    double ypi = cp_ci(xpi, c, G, t);
    VectorXd xmi = x;
    xmi(i) = xmi(i) - delta;
    double ymi = cp_ci(xmi, c, G, t);
    g(i) = (ypi - ymi) / (2.0*delta);
    for (int j=i; j<x.size(); j++) {
      VectorXd xpipj = xpi;
      xpipj(j) = xpipj(j) + delta;
      double ypipj = cp_ci(xpipj, c, G, t);
      VectorXd xpimj = xpi;
      xpimj(j) = xpimj(j) - delta;
      double ypimj = cp_ci(xpimj, c, G, t);
      VectorXd xmipj = xmi;
      xmipj(j) = xmipj(j) + delta;
      double ymipj = cp_ci(xmipj, c, G, t);
      VectorXd xmimj = xmi;
      xmimj(j) = xmimj(j) - delta;
      double ymimj = cp_ci(xmimj, c, G, t);
      H(i,j) = (ypipj - ymipj - ypimj + ymimj) / (4.0*delta*delta);
      if (i != j)
        H(j,i) = H(i,j);
    }
  }
}

void ChowLiuTree::_ensure_conservative_ci (void) {

  MatrixXd U;
  MatrixXd D;
  eig_lowrank (_clt_info.L, U, D, GLC_EPS*10);
  if (U.rows() == 0) { // no information, just return
    cout << "[ci]\t\tNo information, skipping." << endl;
    return;
  }
  MatrixXd Dinv = D.inverse();         // TODO dont use .inverse() for a diagonal matrix

  int n = factors.size();
  VectorXd x(n);
  x.setConstant(1.0/(double)n);          // initial guess of variable
  //x = VectorXd::Random(n).array().abs();
  //x = x / x.sum();
  vector<MatrixXd> G(n);
  VectorXd c(n);
  for (int i=0; i<n; i++) {
    // expand the information for this factor up to the full size of the factor
    MatrixXd Li = _expand_factor_information (factors[i]);
    G[i] = U.transpose()*Li*U;
    c(i) = (G[i]*Dinv).trace();
  }

  // optimize
  int max_iters = 1000;
  int total_iters = 0;
  double t = 1;
  double a = 10;
  double alpha = 0.1; // BT line search param 0.0 < alpha < 0.5 (small means willing to accept small improvements)
  double beta = 0.8;  // BT line search param 0.0 < beta < 1.0 (large means more refined search)

  MatrixXd Gx = linear_matrix(G, x);
  SelfAdjointEigenSolver<MatrixXd> eGx(Gx);
  cout << "[ci]\t\tInitial min eigenvalue of G(x) = " << eGx.eigenvalues().minCoeff() << endl;
  if (eGx.eigenvalues().minCoeff() < 0) {
    cout << "WARNING: infesable starting point. Returning initial CI result." << endl;
    // return initial CI result
    for (int i=0; i<n; i++)
      factors[i].L *= x(i);
    return;
  }

  double init_cost = kld_cost (x, c, linear_matrix(G, x));
  cout << "[ci]\t\tInitial cost: " << init_cost << endl;
  while ((x.size()/t) > 1e-6) { // x.size() == num_constraints, one per variable
    int iters_cnt = 0;
    while (iters_cnt < max_iters) {
      VectorXd g;
      MatrixXd H;
      diff_cp_ci (g, H, x, c, G, t);
      if (0) { // test analytical diff with numerical
        VectorXd gn;
        MatrixXd Hn;
        diff_cp_num_ci (gn, Hn, x, c, G, t);
        cout << "T = " << t << " ============================================================" << endl;
        cout << "g:" << endl << g.transpose() << endl;
        cout << "gn:" << endl << gn.transpose() << endl;
        cout << "g-gn:" << endl << (g - gn).transpose() << endl;
        cout << "H:" << endl << H << endl;
        cout << "Hn:" << endl << Hn << endl;
        cout << "H-Hn:" << endl << H - Hn << endl;
        break;
      }

      MatrixXd K(x.size()+1,x.size()+1);
      K << H, VectorXd::Constant(x.size(), 1.0), VectorXd::Constant(x.size(), 1.0).transpose(), 0.0;
      VectorXd r(x.size()+1);
      r << -g, 0.0;
      FullPivLU<MatrixXd> KLU(K);
      if (KLU.rank() < K.rows()) {
        cout << "WARNING: K rank = " << KLU.rank() << " < " << K.rows() << endl;
      }
      VectorXd d = KLU.solve(r);
      VectorXd dn = d.head(x.size());

      double lambda_sq = (dn.transpose()*H*dn);
      if (lambda_sq/2.0 < 1e-6)
        break;

      // backtracing line search
      double h = 1.0;
      double cpc = cp_ci (x, c, G, t);
      while (cp_ci (x+h*dn, c, G, t) > cpc + alpha*h*g.transpose()*dn)
        h = beta*h;

      x = x + h*dn;
      iters_cnt++;
    }
    total_iters += iters_cnt;
    t *= a;

    if (iters_cnt == max_iters)
      cout << "[ci]\t\tWARNING: Max itterations reached: " << max_iters << endl;
  }
  double final_cost = kld_cost (x, c, linear_matrix(G, x));

  cout << "[ci]\t\tOptimized in " << total_iters << " iterations." << endl;
  cout << "[ci]\t\tReduced cost from " << init_cost << "  to " << final_cost << endl;
  cout << "[ci]\t\tOptimal x = " << x.transpose() << endl;
  if (fabs(x.sum() - 1.0) > 1e-6) {
    cout << "ERROR: sum(x) != 1.0: " << x.transpose() << endl;
    exit(EXIT_FAILURE);
  }
  for (int i=0; i<x.size(); i++){
    if (x(i) <= 0) {
      cout << "ERROR: xi < 0: " << x.transpose() << endl;
      exit(EXIT_FAILURE);
    }
  }

  // set output
  for (int i=0; i<n; i++)
    factors[i].L *= x(i);

}

// -- weighted factors ------------------------------------------------------------------------

MatrixXd Fofx (const vector<MatrixXd> &F, const VectorXd &x, const MatrixXd &L, double eps) {
  MatrixXd Fx = L + MatrixXd::Identity(L.rows(), L.cols())*eps;
  Fx -= linear_matrix(F, x);
  return Fx;
}

// central path for weighted factors and weighted eigenvectors
double cp_w (const VectorXd &x, const VectorXd &c, const vector<MatrixXd> &G,
              const vector<MatrixXd> &F, const MatrixXd &L, double eps, double t) {
  MatrixXd Fx = Fofx(F, x, L, eps);
  for (int i=0; i<x.size(); i++){
    if (x(i) <= 0 || x(i) >= 1.0)
      return numeric_limits<double>::max();
  }
  SelfAdjointEigenSolver<MatrixXd> eFx(Fx);
  if (eFx.eigenvalues().minCoeff() < 0) {
    return numeric_limits<double>::max();
  }
  double cp = kld_cost(x, c, linear_matrix(G, x));// KLD cost
  cp += -(1.0/t)*x.array().log().sum();           // xi greater than zero cost
  cp += -(1.0/t)*(1.0-x.array()).log().sum();   // xi less than 1 cost
  cp += -(1.0/t)*logdet_chol(Fx);                 // consistency constraint cost
  return cp;
}

// grad and hess of central path for weighted factors and weighted eigenvectors
void diff_cp_w (VectorXd &g, MatrixXd &H, const VectorXd &x, const VectorXd &c, const vector<MatrixXd> &G,
                 const vector<MatrixXd> &F, const MatrixXd &L, double eps, double t) {
  g = VectorXd(x.size());
  H = MatrixXd(x.size(),x.size());
  MatrixXd Gx = linear_matrix(G, x);
  MatrixXd Fx = Fofx(F, x, L, eps);
  for (int i=0; i<x.size(); i++) {
    MatrixXd inv_Gx_Gi = Gx.llt().solve(G[i]);
    MatrixXd inv_Fx_Fi = Fx.llt().solve(F[i]);
    g(i) = c(i) - inv_Gx_Gi.trace();      // KLD cost
    g(i) += -(1.0/t)*(1.0/x(i));          // xi greater than zero cost
    g(i) += +(1.0/t)*(1.0/(1.0-x(i)));    // xi less than 1 cost
    g(i) += +(1.0/t)*inv_Fx_Fi.trace();   // consistency constraint cost
    for (int j=i; j<x.size(); j++) {
      H(i,j) = (inv_Gx_Gi*Gx.llt().solve(G[j])).trace();            // KLD cost
      H(i,j) += +(1.0/t)*(inv_Fx_Fi*Fx.llt().solve(F[j])).trace();  // consistency constraint cost
      if (i == j){
        H(i,j) += (1.0/t)*1.0/(x(i)*x(i));                          // xi greater than zero cost
        H(i,j) += (1.0/t)*1.0/((1.0-x(i))*(1.0-x(i)));              // xi less than 1 cost
      } else{
        H(j,i) = H(i,j);
      }
    }
  }
}

void diff_cp_num_w (VectorXd &g, MatrixXd &H, const VectorXd &x, const VectorXd &c, const vector<MatrixXd> &G,
                     const vector<MatrixXd> &F, const MatrixXd &L, double eps, double t) {
  double delta = 1e-6;
  g = VectorXd(x.size());
  H = MatrixXd(x.size(),x.size());
  for (int i=0; i<x.size(); i++) {
    VectorXd xpi = x;
    xpi(i) = xpi(i) + delta;
    double ypi = cp_w(xpi, c, G, F, L, eps, t);
    VectorXd xmi = x;
    xmi(i) = xmi(i) - delta;
    double ymi = cp_w(xmi, c, G, F, L, eps, t);
    g(i) = (ypi - ymi) / (2.0*delta);
    for (int j=i; j<x.size(); j++) {
      VectorXd xpipj = xpi;
      xpipj(j) = xpipj(j) + delta;
      double ypipj = cp_w(xpipj, c, G, F, L, eps, t);
      VectorXd xpimj = xpi;
      xpimj(j) = xpimj(j) - delta;
      double ypimj = cp_w(xpimj, c, G, F, L, eps, t);
      VectorXd xmipj = xmi;
      xmipj(j) = xmipj(j) + delta;
      double ymipj = cp_w(xmipj, c, G, F, L, eps, t);
      VectorXd xmimj = xmi;
      xmimj(j) = xmimj(j) - delta;
      double ymimj = cp_w(xmimj, c, G, F, L, eps, t);
      H(i,j) = (ypipj - ymipj - ypimj + ymimj) / (4.0*delta*delta);
      if (i != j)
        H(j,i) = H(i,j);
    }
  }
}


void ChowLiuTree::_ensure_conservative_wf (void) {

  MatrixXd U;
  MatrixXd D;
  eig_lowrank (_clt_info.L, U, D, GLC_EPS*10); // make sure matches with tolerance used in calc_factors
  if (U.rows() == 0){ // no information, just return
    cout << "[wf]\t\tNo information, skipping." << endl;
    return;
  }
  MatrixXd Dinv = D.inverse();         // TODO dont use .inverse() for a diagonal matrix
  int n = factors.size();
  VectorXd x(n);
  x.setConstant(1.0/(double)n);        // initial guess of variable
  vector<MatrixXd> G(n);
  vector<MatrixXd> F(n);
  VectorXd c(n);
  for (int i=0; i<n; i++) {
    // expand the information for this factor up to the full size of the factor
    MatrixXd Li = _expand_factor_information (factors[i]);
    G[i] = U.transpose()*Li*U;
    F[i] = Li;
    c(i) = (G[i]*Dinv).trace();
  }

  // optimize
  int max_iters = 100;
  int total_iters = 0;
  double t = 1;
  double a = 10;
  double alpha = 0.1; // BT line search param 0.0 < alpha < 0.5 (small means willing to accept small improvements)
  double beta = 0.8;  // BT line search param 0.0 < beta < 1.0 (large means more refined search)
  double eps = 1e-1;

  // check initial starting point
  MatrixXd Gx = linear_matrix(G, x);
  SelfAdjointEigenSolver<MatrixXd> eGx(Gx);
  cout << "[jv]\t\tInitial min eigenvalue of G(x) = " << eGx.eigenvalues().minCoeff() << endl;
  if (eGx.eigenvalues().minCoeff() < 0) {
    cout << "WARNING: infesable starting point. Falling back to covariance intersection." << endl;
    _ensure_conservative_ci ();
    return;
  }
  MatrixXd Fx = Fofx(F, x, _clt_info.L, eps);
  SelfAdjointEigenSolver<MatrixXd> eFx(Fx);
  cout << "[wf]\t\tInitial min eigenvalue of F(x) = " << eFx.eigenvalues().minCoeff() << endl;
  if (eFx.eigenvalues().minCoeff() < 0) {
    cout << "WARNING: infesable starting point. Falling back to covariance intersection." << endl;
    _ensure_conservative_ci ();
    return;
  }
  // check intial cost
  double init_cost = kld_cost (x, c, linear_matrix(G, x));
  cout << "[wf]\t\tInitial cost: " << init_cost << endl;

  int nc = 2*x.size()+1; // number of constraints
  while ((nc/t) > GLC_EPS) {
    int iters_cnt = 0;
    while (iters_cnt < max_iters) {
      VectorXd g;
      MatrixXd H;
      diff_cp_w (g, H, x, c, G, F, _clt_info.L, eps, t);
      if (0) { // test analytical diff with numerical
        VectorXd gn;
        MatrixXd Hn;
        diff_cp_num_w (gn, Hn, x, c, G, F, _clt_info.L, eps, t);
        cout << "T = " << t << " ============================================================" << endl;
        cout << "g:" << endl << g.transpose() << endl;
        cout << "gn:" << endl << gn.transpose() << endl;
        cout << "g-gn:" << endl << (g - gn).transpose() << endl;
        cout << "H:" << endl << H << endl;
        cout << "Hn:" << endl << Hn << endl;
        cout << "H-Hn:" << endl << H - Hn << endl;
        break;
      }

      FullPivLU<MatrixXd> HLU(H);
      if (HLU.rank() < H.rows()) {
        cout << "WARNING: H rank = " << HLU.rank() << " < " << H.rows() << endl;
      }
      VectorXd dn = -HLU.solve(g);

      // backtracing line search
      double h = 1.0;
      double cpc = cp_w (x, c, G, F, _clt_info.L, eps, t);
      while (cp_w (x+h*dn, c, G, F, _clt_info.L, eps, t) > cpc + alpha*h*g.transpose()*dn)
        h = beta*h;

      double lambda_sq = (dn.transpose()*H*dn);
      //cout << "Step: lambda_sq = " << lambda_sq << " h = " << h << endl;;
      if (lambda_sq/2.0 < GLC_EPS)
        break;

      x = x + h*dn;
      iters_cnt++;
    }
    total_iters += iters_cnt;
    t *= a;

    if (iters_cnt == max_iters)
      cout << "[wf]\t\tWARNING: Max itterations reached: " << max_iters << endl;
  }
  double final_cost = kld_cost (x, c, linear_matrix(G, x));

  cout << "[wf]\t\tOptimized in " << total_iters << " iterations." << endl;
  cout << "[wf]\t\tReduced cost from " << init_cost << "  to " << final_cost << endl;
  cout << "[wf]\t\tOptimal x = " << x.transpose() << endl;
  for (int i=0; i<x.size(); i++){
    if (x(i) <= 0 || x(i) > 1.0) {
      cout << "ERROR: xi < 0 || xi > 1.0: " << x.transpose() << endl;
      exit(EXIT_FAILURE);
    }
  }

  // set output
  for (int i=0; i<n; i++)
    factors[i].L *= x(i);
}

// -- Weighted eigen values ----------------------------------------------------------------------------------

void ChowLiuTree::_ensure_conservative_wev(void) {

  MatrixXd U;
  MatrixXd D;
  eig_lowrank (_clt_info.L, U, D, GLC_EPS*10);
  if (U.rows() == 0){ // no information, just return
    cout << "[wev]\t\tNo information, skipping." << endl;
    return;
  }
  MatrixXd Dinv = D.inverse();         // TODO dont use .inverse() for a diagonal matrix
  int m=0;
  vector<MatrixXd> G;
  vector<MatrixXd> F;
  vector<MatrixXd> Ucache; // save the eigen decomps of each factor for reconstruction at the end
  vector<MatrixXd> Dcache;
  for (size_t i=0; i<factors.size(); i++) {
    MatrixXd Li = _expand_factor_information (factors[i]);
    MatrixXd Ui;
    MatrixXd Di;
    eig_lowrank (Li, Ui, Di, GLC_EPS*10);
    Ucache.push_back(Ui);
    Dcache.push_back(Di);
    for (int j=0; j<Di.rows(); j++) {
      MatrixXd Eij =  Di(j,j)*Ui.col(j)*Ui.col(j).transpose();
      F.push_back(Eij);
      G.push_back(U.transpose()*Eij*U);
      m++;
    }
  }
  VectorXd c(m);
  VectorXd x(m);
  double w = 1.0/(double)factors.size();
  for (int i=0; i<m; i++) {
    c(i) = (G[i]*Dinv).trace();
    x(i) = w;
  }

  // optimize
  int max_iters = 100;
  int total_iters = 0;
  double t = 1;
  double a = 10;
  double alpha = 0.1; // BT line search param 0.0 < alpha < 0.5 (small means willing to accept small improvements)
  double beta = 0.8;  // BT line search param 0.0 < beta < 1.0 (large means more refined search)
  double eps = 1e-1;

  // check initial starting point
  MatrixXd Gx = linear_matrix(G, x);
  SelfAdjointEigenSolver<MatrixXd> eGx(Gx);
  cout << "[wev]\t\tInitial min eigenvalue of G(x) = " << eGx.eigenvalues().minCoeff() << endl;
  if (eGx.eigenvalues().minCoeff() < 0) {
    cout << "WARTNING: infesable starting point. Falling back to weighted factors." << endl;
    _ensure_conservative_wf();
    return;
  }
  MatrixXd Fx = Fofx(F, x, _clt_info.L, eps);
  SelfAdjointEigenSolver<MatrixXd> eFx(Fx);
  cout << "[wev]\t\tInitial min eigenvalue of F(x) = " << eFx.eigenvalues().minCoeff() << endl;
  if (eFx.eigenvalues().minCoeff() < 0) {
    cout << "WARNING: infesable starting point. Falling back to weighted factors." << endl;
    _ensure_conservative_wf();
    return;
  }
  
  // check intial cost
  double init_cost = kld_cost (x, c, linear_matrix(G, x));
  cout << "[wev]\t\tInitial cost: " << init_cost << endl;
  
  int nc = 2*x.size()+1; // number of constraints
  while ((nc/t) > GLC_EPS) {
    int iters_cnt = 0;
    while (iters_cnt < max_iters) {
      VectorXd g;
      MatrixXd H;
      diff_cp_w (g, H, x, c, G, F, _clt_info.L, eps, t);
      
      if (0) { // test analytical diff with numerical
        VectorXd gn;
        MatrixXd Hn;
        diff_cp_num_w (gn, Hn, x, c, G, F, _clt_info.L, eps, t);
        cout << "T = " << t << " ============================================================" << endl;
        cout << "g:" << endl << g.transpose() << endl;
        cout << "gn:" << endl << gn.transpose() << endl;
        cout << "g-gn:" << endl << (g - gn).transpose() << endl;
        cout << "H:" << endl << H << endl;
        cout << "Hn:" << endl << Hn << endl;
        cout << "H-Hn:" << endl << H - Hn << endl;
        break;
      }

      FullPivLU<MatrixXd> HLU(H);
      if (HLU.rank() < H.rows()) {
        cout << "WARNING: H rank = " << HLU.rank() << " < " << H.rows() << endl;
      }
      VectorXd dn = -HLU.solve(g);

      // backtracing line search
      double h = 1.0;
      double cpc = cp_w (x, c, G, F, _clt_info.L, eps, t);
      while (cp_w (x+h*dn, c, G, F, _clt_info.L, eps, t) > cpc + alpha*h*g.transpose()*dn)
        h = beta*h;

      double lambda_sq = (dn.transpose()*H*dn);
      //cout << "Step: lambda_sq = " << lambda_sq << " h = " << h << endl;;
      if (lambda_sq/2.0 < GLC_EPS)
        break;

      x = x + h*dn;
      iters_cnt++;
    }
    total_iters += iters_cnt;
    t *= a;

    if (iters_cnt == max_iters)
      cout << "[wev]\t\tWARNING: Max itterations reached: " << max_iters << endl;
  }
  double final_cost = kld_cost (x, c, linear_matrix(G, x));

  cout << "[wev]\t\tOptimized in " << total_iters << " iterations." << endl;
  cout << "[wev]\t\tReduced cost from " << init_cost << "  to " << final_cost << endl;
  cout << "[wev]\t\tOptimal x = " << x.transpose() << endl;
  for (int i=0; i<x.size(); i++){
    if (x(i) <= 0 || x(i) > 1.0) {
      cout << "ERROR: xi < 0 || xi > 1.0: " << x.transpose() << endl;
      exit(EXIT_FAILURE);
    }
  }

  m = 0;
  vector<ChowLiuTreeFactor>::iterator it = factors.begin();
  for (size_t i=0; i<Dcache.size(); i++) {
    MatrixXd Di = Dcache[i];
    MatrixXd Ui = Ucache[i];
    if (Di.rows() == 0) { // might happen for root nodes
      it = factors.erase(it);
    } else {
      for (int j=0; j<Di.rows(); j++) {
        Di(j,j) *= x(m);
        m++;
      }
      MatrixXd L_full = Ui*Di*Ui.transpose();
      _unexpand_factor_information (L_full, *it);
      ++it;
    }
  }
}

// -- John Vial's Method -------------------------------------------------------------------------------------

MatrixXd Eofx (const vector<MatrixXd> &E, const VectorXd &x, double eps) {
  return linear_matrix(E, x) + MatrixXd::Identity(E[0].rows(), E[0].cols())*eps;
}

// central path for covariance intersection
double cp_jv (const VectorXd &x, const VectorXd &c,
              const vector<MatrixXd> &G,  const vector<MatrixXd> &E,
              const MatrixXd &L, double eps, double t) {

  MatrixXd Gx = linear_matrix(G, x);
  SelfAdjointEigenSolver<MatrixXd> eGx(Gx);
  if (eGx.info() != Eigen::Success) {
    cout << "WARNING: failed to compute eigenvalues for Gx" << endl;
  }
  if (eGx.eigenvalues().minCoeff() < 0) {
    return numeric_limits<double>::max();
  }
  MatrixXd Ex = Eofx(E, x, eps) ;
  SelfAdjointEigenSolver<MatrixXd> eEx(Ex);
  if (eEx.info() != Eigen::Success) {
    cout << "WARNING: failed to compute eigenvalues for Ex" << endl;
  }
  if (eEx.eigenvalues().minCoeff() < 0) {
    return numeric_limits<double>::max();
  }
  MatrixXd Fx = Fofx(E, x, L, eps);
  SelfAdjointEigenSolver<MatrixXd> eFx(Fx);
  if (eFx.info() != Eigen::Success) {
    cout << "WARNING: failed to compute eigenvalues for Fx" << endl;
  }
  if (eFx.eigenvalues().minCoeff() < 0) {
    return numeric_limits<double>::max();
  }
  double cp = kld_cost(x, c, Gx);  // KLD cost
  cp += -(1.0/t)*logdet_chol(Fx);  // consistency constraint cost
  cp += -(1.0/t)*logdet_chol(Ex);  // E psd cost
  return cp;
}

// grad and hess of central path for covariance intersection
void diff_cp_jv (VectorXd &g, MatrixXd &H, const VectorXd &x, const VectorXd &c,
                 const vector<MatrixXd> &G,  const vector<MatrixXd> &E,
                 const MatrixXd &L, double eps, double t) {
  g = VectorXd(x.size());
  H = MatrixXd(x.size(),x.size());
  MatrixXd Gx = linear_matrix(G, x);
  MatrixXd Fx = Fofx(E, x, L, eps);
  MatrixXd Ex = Eofx(E, x, eps) ;
  for (int i=0; i<x.size(); i++) {
    MatrixXd inv_Gx_Gi = Gx.llt().solve(G[i]);
    MatrixXd inv_Fx_Fi = Fx.llt().solve(E[i]);
    MatrixXd inv_Ex_Ei = Ex.llt().solve(E[i]);
    g(i) = c(i) - inv_Gx_Gi.trace();      // KLD cost
    g(i) += +(1.0/t)*inv_Fx_Fi.trace();   // consistency constraint cost
    g(i) += -(1.0/t)*inv_Ex_Ei.trace();   // E psd cost
    for (int j=i; j<x.size(); j++) {
      H(i,j) = (inv_Gx_Gi*Gx.llt().solve(G[j])).trace();            // KLD cost
      H(i,j) += +(1.0/t)*(inv_Fx_Fi*Fx.llt().solve(E[j])).trace();  // consistency constraint cost
      H(i,j) += +(1.0/t)*(inv_Ex_Ei*Ex.llt().solve(E[j])).trace();  // E psd cost
      if (i != j){
        H(j,i) = H(i,j);
      }
    }
  }
}

void diff_cp_num_jv (VectorXd &g, MatrixXd &H, const VectorXd &x, const VectorXd &c,
                     const vector<MatrixXd> &G,  const vector<MatrixXd> &E,
                     const MatrixXd &L, double eps, double t) {
  double delta = 1e-4;
  g = VectorXd(x.size());
  H = MatrixXd(x.size(),x.size());
  for (int i=0; i<x.size(); i++) {
    VectorXd xpi = x;
    xpi(i) = xpi(i) + delta;
    double ypi = cp_jv(xpi, c, G, E, L, eps, t);
    VectorXd xmi = x;
    xmi(i) = xmi(i) - delta;
    double ymi = cp_jv(xmi, c, G, E, L, eps, t);
    g(i) = (ypi - ymi) / (2.0*delta);
    for (int j=i; j<x.size(); j++) {
      VectorXd xpipj = xpi;
      xpipj(j) = xpipj(j) + delta;
      double ypipj = cp_jv(xpipj, c, G, E, L, eps, t);
      VectorXd xpimj = xpi;
      xpimj(j) = xpimj(j) - delta;
      double ypimj = cp_jv(xpimj, c, G, E, L, eps, t);
      VectorXd xmipj = xmi;
      xmipj(j) = xmipj(j) + delta;
      double ymipj = cp_jv(xmipj, c, G, E, L, eps, t);
      VectorXd xmimj = xmi;
      xmimj(j) = xmimj(j) - delta;
      double ymimj = cp_jv(xmimj, c, G, E, L, eps, t);
      H(i,j) = (ypipj - ymipj - ypimj + ymimj) / (4.0*delta*delta);
      if (i != j)
        H(j,i) = H(i,j);
    }
  }
}


MatrixXb ChowLiuTree::_sparsity_pattern (void) {

  MatrixXb S(_clt_info.L.rows(),_clt_info.L.rows());
  S.setConstant(false);

  for (size_t n=0; n<factors.size(); n++) {
    int ioff = 0;
    int idim = factors[n].nodes[0]->dim();
    for (size_t i=0; i<_clt_info.nodes.size(); i++) {
      if (factors[n].nodes[0] == _clt_info.nodes[i])
        break;
      else
        ioff += _clt_info.nodes[i]->dim();
    }
    S.block(ioff,ioff,idim,idim).setConstant(true);

    if (factors[n].nodes.size() > 1) {
      int joff = 0;
      int jdim = factors[n].nodes[1]->dim();
      for (size_t i=0; i<_clt_info.nodes.size(); i++) {
      if (factors[n].nodes[1] == _clt_info.nodes[i])
        break;
      else
        joff += _clt_info.nodes[i]->dim();
      }
      S.block(joff,joff,jdim,jdim).setConstant(true);
      S.block(ioff,joff,idim,jdim).setConstant(true);
      S.block(joff,ioff,jdim,idim).setConstant(true);
    }
  }
  return S;

}

void ChowLiuTree::_ensure_conservative_jv (void) {

  MatrixXb S = _sparsity_pattern ();
  MatrixXd U;
  MatrixXd D;
  eig_lowrank (_clt_info.L, U, D, GLC_EPS*10);
  MatrixXd Dinv = D.inverse();
  int n=S.rows();
  // compute the covariance intersection as the initial guess
  MatrixXd Ls_init (n,n);
  Ls_init.setZero();
  double w = 1.0/(double)factors.size();
  for (size_t i=0; i<factors.size(); i++) {
    Ls_init += w*_expand_factor_information (factors[i]);
  }
  int m=0;
  vector<MatrixXd> G;
  vector<MatrixXd> E;
  vector<double> x_init;
  for (int i=0; i<n; i++) {
    for (int j=i; j<n; j++) {
      if (S(i,j)) {
        MatrixXd Ei(n,n);
        Ei.setZero();
        Ei(i,j) = 1.0;
        Ei(j,i) = 1.0;
        G.push_back(U.transpose()*Ei*U);
        E.push_back(Ei);
        x_init.push_back(Ls_init(i,j));
        m++;
      }
    }
  }
  VectorXd c(m);
  VectorXd x(m);
  for (int i=0; i<m; i++) {
    c(i) = (G[i]*Dinv).trace();
    x(i) = x_init[i];
  }

  // optimize
  int max_iters = 10;
  int total_iters = 0;
  double t = 1;
  double a = 10;
  double alpha = 0.1; // BT line search param 0.0 < alpha < 0.5 (small means willing to accept small improvements)
  double beta = 0.8;  // BT line search param 0.0 < beta < 1.0 (large means more refined search)
  double eps = 1e-1;

  // check initial starting point
  MatrixXd Gx = linear_matrix(G, x);
  SelfAdjointEigenSolver<MatrixXd> eGx(Gx);
  cout << "[jv]\t\tInitial min eigenvalue of G(x) = " << eGx.eigenvalues().minCoeff() << endl;
  if (eGx.eigenvalues().minCoeff() < 0) {
    cout << "ERROR: infesable starting point!" << endl;
    exit(EXIT_FAILURE);
  }
  MatrixXd Ex = Eofx(E, x, eps);
  SelfAdjointEigenSolver<MatrixXd> eEx(Ex);
  cout << "[jv]\t\tInitial min eigenvalue of E(x) = " << eEx.eigenvalues().minCoeff() << endl;
  if (eEx.eigenvalues().minCoeff() < 0) {
    cout << "ERROR: infesable starting point!" << endl;
    exit(EXIT_FAILURE);
  }
  MatrixXd Fx = Fofx(E, x, _clt_info.L, eps);
  SelfAdjointEigenSolver<MatrixXd> eFx(Fx);
  cout << "[jv]\t\tInitial min eigenvalue of F(x) = " << eFx.eigenvalues().minCoeff() << endl;
  if (eFx.eigenvalues().minCoeff() < 0) {
    cout << "ERROR: infesable starting point!" << endl;
    exit(EXIT_FAILURE);
  }

  // check intial cost
  double init_cost = kld_cost (x, c, linear_matrix(G, x));
  cout << "[jv]\t\tInitial cost: " << init_cost << endl;

  int nc = 2; // number of constraints
  while ((nc/t) > GLC_EPS) {
    int iters_cnt = 0;
    while (iters_cnt < max_iters) {
      VectorXd g;
      MatrixXd H;
      diff_cp_jv (g, H, x, c, G, E, _clt_info.L, eps, t);
      if (0) { // test analytical diff with numerical
        VectorXd gn;
        MatrixXd Hn;
        diff_cp_num_jv (gn, Hn, x, c, G, E, _clt_info.L, eps, t);
        cout << "T = " << t << " ============================================================" << endl;
        MatrixXd gd = (g-gn).array().abs();
        cout << "g:    mean = " << g.array().abs().matrix().mean() << " max = " << g.array().abs().matrix().maxCoeff() << endl;
        cout << "gn:   mean = " << gn.array().abs().matrix().mean() << " max = " << gn.array().abs().matrix().maxCoeff() << endl;
        cout << "g-gn: mean = " << gd.mean() << " max = " << gd.maxCoeff() << endl;
        //cout << "g = [" << g.transpose() << "];" << endl;
        //cout << "gn = [" << gn.transpose() << "];" <<  endl;
        MatrixXd Hd = (H-Hn).array().abs();
        cout << "H:    mean = " << H.array().abs().matrix().mean() << " max = " << H.array().abs().matrix().maxCoeff() << endl;
        cout << "Hn:   mean = " << Hn.array().abs().matrix().mean() << " max = " << Hn.array().abs().matrix().maxCoeff() << endl;
        cout << "H-Hn: mean = " << Hd.mean() << " max = " << Hd.maxCoeff() << endl;
        //cerr << "H = [" << H << "];" << endl;
        //cerr << "Hn = [" << Hn << "];" <<  endl;
        break;
      }

      FullPivLU<MatrixXd> HLU (H);
      if (HLU.rank() < H.rows()) {
        cout << "WARNING: H rank = " << HLU.rank() << " < " << H.rows() << endl;
      }
      VectorXd dn = -HLU.solve(g);

      // backtracing line search
      double h = 1.0;
      double cpc = cp_jv (x, c, G, E, _clt_info.L, eps, t);
      while (cp_jv (x+h*dn, c, G, E, _clt_info.L, eps, t) > cpc + alpha*h*g.transpose()*dn)
        h = beta*h;

      double lambda_sq = (dn.transpose()*H*dn);
      cout << "Step: lambda_sq = " << lambda_sq << " h = " << h << endl;;
      if (lambda_sq/2.0 < GLC_EPS)
        break;

      x = x + h*dn;
      iters_cnt++;
    }
    total_iters += iters_cnt;
    t *= a;

    if (iters_cnt == max_iters)
      cout << "[jv]\t\tWARNING: Max itterations reached: " << max_iters << endl;
  }
  double final_cost = kld_cost (x, c, linear_matrix(G, x));

  cout << "[jv]\t\tOptimized in " << total_iters << " iterations." << endl;
  cout << "[jv]\t\tReduced cost from " << init_cost << "  to " << final_cost << endl;

  // set output
  MatrixXd Ls = linear_matrix(E, x);
  MatrixXd Us;
  MatrixXd Ds;
  eig_lowrank (Ls, Us, Ds, GLC_EPS);
  Ls = Us*Ds*Us.transpose();
//cout << "Lt_s = [" << Ls << "];" << endl;
  cout << "[jv]\t\tRank before = " << _clt_info.L.fullPivLu().rank() << " rank after = " << Ls.fullPivLu().rank() << endl;
  _update_info(Ls);
  
}

} //namespace isam