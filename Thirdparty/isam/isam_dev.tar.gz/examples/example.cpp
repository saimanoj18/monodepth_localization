#include <iostream>

#include <vector>

#include <isam/isam.h>
#include <isam/slam2d.h>

using namespace std;
using namespace Eigen;
using namespace isam;

static double
_dcs_func (double chi2, double phi)
{
    double tmp = (2*phi) / (phi + chi2);
    return tmp > 1 ? 1 : tmp;
}

static double
_dcs_wrapper (double chi2)
{
    double phi = 5.;
    return _dcs_func (chi2, phi);
}

static void
_testMaxMixtures ()
{
    scale_func_t cov_scale_func = _dcs_wrapper;
    Slam slam;

    /* first node */
    Pose2d_Node *node0 = new Pose2d_Node ();
    Pose2d priorZ (0, 0, 0);
    Noise priorR = Information (MatrixXd::Identity (3,3) * 1e7);
    Pose2d_Factor *prior = new Pose2d_Factor (node0, priorZ, priorR);
    slam.add_node (node0);
    slam.add_factor (prior);

    /* first node sees second node */
    Pose2d_Node *node1 = new Pose2d_Node ();
    Pose2d odom01Z (10, 0, 0);
    Noise odom01R = Information (MatrixXd::Identity (3, 3) * 1);
    Pose2d_Pose2d_Factor *odom01 = new Pose2d_Pose2d_Factor (node0, node1, odom01Z, odom01R);
    slam.add_node (node1);
    slam.add_factor (odom01);

    /* second node sees third node */
    Pose2d_Node *node2 = new Pose2d_Node ();
    Pose2d odom12Z (10, 0, 0);
    Noise odom12R = Information (MatrixXd::Identity (3, 3) * 1);
    Pose2d_Pose2d_Factor *odom12 = new Pose2d_Pose2d_Factor (node1, node2, odom12Z, odom12R);
    slam.add_node (node2);
    slam.add_factor (odom12);

    /* third node sees bogus loop closure */
    Pose2d odom02Z (25, 0, 0);
    /* regular, non-mm */
    /* Noise odom02R = Information (MatrixXd::Identity (3, 3) * 100); */
    /* Pose2d_Pose2d_Factor *odom02 = new Pose2d_Pose2d_Factor (node0, node2, odom02Z, odom02R); */
    Pose2d_Pose2d_Factor *odom02 = new Pose2d_Pose2d_Factor (node0, node2, odom02Z, Information (MatrixXd::Identity (3, 3)));
    slam.add_factor (odom02);

    MaxMixtureComponent c1 (3), c2 (3);
    c1.weight = 1e-3;
    c2.weight = 1;
    c1.noise = Information (MatrixXd::Identity (3, 3) * 1e-3);
    c2.noise = Information (MatrixXd::Identity (3, 3) * 100);

    vector<MaxMixtureComponent> mm;
    mm.push_back (c1);
    mm.push_back (c2);
    odom02->set_max_mixtures (mm);
    /* odom02->set_scale_function (&cov_scale_func); */

    slam.batch_optimization ();
    slam.write (cout);
    slam.print_stats ();
}

int
main (int argc, char *argv[])
{
    _testMaxMixtures ();
}
